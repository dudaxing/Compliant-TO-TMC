# L-CTIPFSTEP1 science worker／普通checker实现

**已编写、仅AST解析，未执行／导入这两模块；正式科学窗口尚未由本子任务启动。** 根负责冻结、独立静审及唯一执行。

|文件|字节|SHA256|
|---|---:|---|
|`D:/hfst1_001/science_step1.py`|10160|9d05251bc62935a54db78f989dc41e918eeaf4c758ce3c0f388ed7d65e4b12cf|
|`D:/hfst1_001/check_step1.py`|14928|92f3b173a7e9472ac9191cba23171d17e47ad22c13c574effcb01831674ec863|

## 科学薄worker

`science_step1.py`只在实际main窗口校普通bindings后导入已安装`extend_native_guided_force`并调用一次。承接完整[P0,P1,P2]、controller1800及直接HIGH1末态，不传q、物理或非clock覆盖。原API负责实际几何/模型/split准入、fresh及所有力核/切线/平衡，不在worker复制内核。

old3NPZ与new RUN/force输出open事件分开：旧科学写入和名单外旧科学读取停止；新NPZ正常raw写/hash/readback允许并另记。open能力观察不等于字段解码计数；只有API返回、意味着源码准入流已完成时记2解码档/6字段，并声明不是动态字段hook。实际partial和API返回计数先入回执再停止，无外部重试。callback只复制实际接受态标量并更新进度，无新增核。

## 普通checker

`check_step1.py`只读BASE/protocol.json与RUN/force/result.json，标准库实现普通canonical/bit检查。核fresh q/P/R binary64及state/两split字段SHA、complete/full/segment/root/source索引与继承、每个接受态原标量门、显式载荷账本和实际P2到达。原F/Hu有限性由生产控制器执行，本checker不伪称解码独立复核。

最多5态仅原Nmin派生一致性核，全部实际行保留，不截数据、不改变controller maxdepth4。新q2未知，给q/HP参考not_available，三误差null，不借旧P1工程界。源/历史只从protocol携带，不另开旧结果或科学NPZ。新容器archiveSHA不额外要求与旧ZIP字节相同；continuation.selected旧archive pin及科学split field/state身份仍严格核。

## 协议约定

必需keys：`stage, runtime_base, production_src, source_binding_file, contract_file, parent_result, loads_half_N, segment_loads_half_N, controller_seconds, bindings, source_selected, source_context, history`。`source_context`为完整准备SOURCE_BINDING对象；`source_selected`为其中selected_force_state；`history`为完整准备HISTORY；`source_force_task`可额外存元数据，不要求checker再开旧JSON。`bindings`只含普通文件/源码，不含NPZ/ZIP/PNG/GIF/SVG。

科学输出science_receipt/science_progress和原force目录；普通核对输出continuation_check，status为pass/failed；reference_comparison按根viewer约定为not_available_no_P2_reference及null三误差。

## 有限源码自查

17项源码/AST自查通过（详机器记录），不是运行测试或功能验证。0 HF导入、0科学/媒体读取、0F/T/HP/平衡、0测试、0worker/checker启动、0生产修改。根随后独立静审和冻结，实际结果以唯一窗口回执为准。
