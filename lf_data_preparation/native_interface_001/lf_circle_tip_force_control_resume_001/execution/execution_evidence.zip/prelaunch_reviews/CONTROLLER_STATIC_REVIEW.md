# L-CTIPFRESUME1 controller 独立源码静审

结论：14 项 PASS。仅 AST / 普通源码与原接口合同核对；没有 HF import、pytest、科学数组读取或数值计算。此审阅不是对审阅人编写的测试源自审。

候选 `split_guided_force.py` SHA `8e902a20e7131733678b5b99aaa9bc5d046323ef151dd73f0681f18198e5dc1f`。

- **C01 scope_imports_settings PASS**：Only controller source read; import AST and GuidedForceSettings class identical to installed baseline.
- **C02 new_scalar_q_validation PASS**：initial_q uses unchanged _vector([value],1): shape1, kind i/u/f, noncomplex finite. Bool/string/list/nonfinite reject invalid_input before assembly.
- **C03 root_force_scalar_validation PASS**：None preserves original segment anchor; explicit finite real scalar separately retained as P_scale_anchor.
- **C04 split_structure PASS**：Existing SplitDisplacement/ndof checked, body-x lift equals absolute initial_q, all other lift zero, original fixed fluctuation zero; conflict raises before assembly.
- **C05 default_compatibility PASS**：Optional q default0/root scale None reduce to original q0 and P_anchor. Public old entry signature/admission unchanged.
- **C06 absolute_q_initial_and_impose PASS**：state_q initialized initial_q; unchanged impose overwrites body-x lift=q rather than accumulating or shifting q origin.
- **C07 root_SP PASS**：Only intended measure scale changes from segment P_anchor to P_scale_anchor; g remains fsum(sum body x,-P), mean/free scales and tolerance unchanged.
- **C08 fresh_no_repair PASS**：newton AST identical: first P==oldP and KNone causes fresh tangent check directly, no predictor; failed original gate produces initial_state_not_equilibrated, no projection/correction.
- **C09 nonsymmetric_KKT PASS**：step AST identical: independent Kfc/Kcf/Kcc body sums, unaveraged generalized row, unsymmetrized sparse solve retained.
- **C10 Newton_Armijo PASS**：newton AST identical: original base/trial residual scales, Armijo factors, feasibility and typed failures unchanged.
- **C11 rollback_bisection PASS**：advance AST identical: both split arrays/R/q/P/K rollback, original maxdepth/minimumN/terminal conditions unchanged.
- **C12 finite_J_timing PASS**：clock/evaluate AST identical: original finite fields, J>0, attempts/completions and time checks unchanged.
- **C13 metadata_segment_root PASS**：measure and top return add explicit initial absolute q, segment anchor/root scale and separate increments; original anchor_force_half_N remains segment first P.
- **C14 shared_API_alignment PASS**：Static API uses common _run_guided_force with initial_body_q_mm, force_scale_anchor_half_N; fresh checks q/P/R binary64 and state hash/checks1; 1.1 maps local to global index, explicit root/source/segment/selected keys match frozen INTERFACE_SPEC. No API execution.

10 个 nested function 的 AST 与已安装基线逐一相同：indices, clock, evaluate, impose, mean_error, feasible, metrics, step, newton, advance。GuidedForceSettings class 与全部 imports 的 AST 相同。

这支持原 KKT/Newton/回滚/门未改的源码结论；实际非零锚点与延伸结果仍须唯一小模型窗口验证，不能把静态 PASS 当作已执行 PASS。
