# API/保存态准入独立静审

14项源码/有限AST核对通过；不是数值测试PASS。当前只在候选树修改，未导入HF、运行测试、读取科学缓存或修改正式源码。

- A01 PASS — Default evaluate signature and every original pre-run validation/admission AST unchanged
- A02 PASS — One shared runner; original assemble/vector_sum AST unchanged; no duplicate force or tangent implementation
- A03 PASS — New public signature has only full targets/output, clock/callback and same-byte fixed-source location
- A04 PASS — Known 1.0/1.1 success/complete-original-terminal semantics checked before selected mechanics
- A05 PASS — Full target prefix canonical identity, strict signed increase, local/global index coverage and segment-only execution
- A06 PASS — Root P0 is independent of segment P; 1.1 anchor/full-first equality and inherited scales retained
- A07 PASS — Opaque original model identity and original geometry/material/regions/ports/body/member equality, two kernel SHA hard gates
- A08 PASS — One selected force-state NPZ, exactly two float64 split fields with archive/field/state hashes and absolute q structure; no fixed q0 cache
- A09 PASS — Fresh cached capture additionally checks q/P/R bits, original state hash and check1; no repair or q-origin reset
- A10 PASS — Nonclock settings and force step inherited; original signed R and body-x external load accounting unchanged
- A11 PASS — Only identity-preserving fixed-parent location and relative model/geometry resolution; output outside both source trees
- A12 PASS — Typed pre-F/T source/input/extension rejection and original numerical partial persistence; save-time F/T remains zero
- A13 PASS — Shallow root/immediate pins and actual relocated path separated from historical source; no recursive ancestor read or full-path recompute claim
- A14 PASS — All qualification flags false; schema1.1 isolated from unchanged default1.0; new module in producer hashes

原evaluate签名和完整准入前缀、assemble/vector_sum均作AST原样比较。新模块按直接父与root固定模型闭包检查，历史root-force pin不当作祖先数值重核。静态结论以本JSON两份源码SHA为准，实际验证待唯一已授权窗口。
