"""Average-port control of split mechanics with an explicit affine lift.

The unknowns are free fluctuation and actuator multiplier. Individual port
nodes are not tied. The residual/Jacobian, force scale, Armijo and bisection
policies are those of the HF3 average controller; the default kernel is unchanged.
"""
from __future__ import annotations

from copy import deepcopy
from math import fma, fsum
from time import perf_counter

import numpy as np

from .displacement import (DisplacementSettings, _check_support, _inputs, _kkt,
                           _linear_solve, _positive_scalar, _vector)
from .split_affine import _bitwise_equal
from .split_kernel import assemble_split
from .split_prescribed import STATE_SCHEMA, state_hash
from .split_state import SplitDisplacement
from .tmc import TMCError
from .tmc_kernel import KernelError


def _dot(arrays, vector, *offsets):
    """Compensate product rounding before summation and target subtraction."""
    terms = list(offsets)
    try:
        for array in arrays:
            for i in np.flatnonzero(vector):
                a, b = float(vector[i]), float(array[i])
                product = a*b
                terms.extend((product, fma(a, b, -product)))
        result = fsum(terms)
    except (ValueError, OverflowError) as error:
        raise TMCError("split port measurement is nonfinite", code="nonfinite") from error
    if not np.isfinite(result):
        raise TMCError("split port measurement is nonfinite", code="nonfinite")
    return result


def split_average_measurement(state, vector, *offsets):
    """Return compensated b·lift+b·fluctuation+offsets, rounded only at exit.

    Include negative target terms here for a constraint residual; do not first
    round the mean and then subtract its target. FMA product compensation is
    for the ordinary bounded mechanical range, not arbitrary-precision algebra.
    """
    if not isinstance(state, SplitDisplacement):
        raise TMCError("state must be SplitDisplacement", code="invalid_input")
    vector = _vector(vector, state.ndof, "measurement_vector")
    return _dot((state.lift, state.fluctuation), vector, *offsets)


def solve_split_displacement_path(model, b_in, b_out, targets, k_out=0., *,
                                 lift_origin=None, lift_shape=None, target_origin=0.,
                                 initial_state=None, initial_R=0., initial_parameter=0., settings=None,
                                 force_scale_per_length, assembler=None, on_accept=None,
                                 path_mode="load_only", initial_guess="tangent",
                                 saved_load_only_anchor=False, prescribed_body=None):
    """Solve fint(L,w)+k*b_out*q_out-b_in*R=0 and b_in·(L+w)=d0+s.

    Targets are nonnegative stage parameters s. ``load_only`` starts at zero and
    requires increasing targets; ``ordered_cycle`` follows the supplied order,
    retaining state and tangent through loading and unloading. The actual
    lift is stored binary64 origin+s*shape; the mean target is the exact sum
    D(target_origin)+D(s). Both lift arrays default to zero. Physical fixed DOFs
    remain zero. A warm start must match the supplied lift at its initial
    parameter bit for bit;
    its multiplier and target offset are explicit. No rebase or display array
    enters mechanics, measurements, feasibility or initialization.
    A nonzero ``initial_parameter`` is an ordered-cycle saved anchor, or an
    explicitly validated load-only anchor with ``saved_load_only_anchor=True``;
    targets start at that absolute s, and its first fresh F/T check must pass
    the existing gates without Newton correction. No saved tangent is accepted.
    ``port_projection`` starts displacement from the previous fluctuation plus
    a distributed port adjustment; the real tangent prediction still seeds R.
    ``prescribed_body`` explicitly opts into a guided rigid-x probe: targets
    are body q, while the input mean remains d_hold. Its nodes retain zero
    fluctuation; only their x lift moves. A supplied q=0 anchor must pass its
    first fresh F/T check without projection or Newton correction.
    """
    settings = DisplacementSettings() if settings is None else settings
    if not isinstance(settings, DisplacementSettings):
        raise TMCError("settings must be DisplacementSettings", code="invalid_settings")
    b_in, b_out, k_out = _inputs(model, b_in, b_out, k_out)
    force_scale_per_length = _positive_scalar(force_scale_per_length, "force_scale_per_length")
    target_origin = _positive_scalar(target_origin, "target_origin", allow_zero=True)
    initial_parameter = _positive_scalar(initial_parameter, "initial_parameter", allow_zero=True)
    initial_R = float(_vector([initial_R], 1, "initial_R")[0])
    raw = np.asarray(targets)
    if raw.ndim != 1 or not len(raw):
        raise TMCError("targets must be a nonempty vector", code="invalid_input")
    levels = _vector(targets, len(raw), "targets")
    if path_mode not in ("load_only", "ordered_cycle"):
        raise TMCError("path_mode must be load_only or ordered_cycle", code="invalid_input")
    if initial_guess not in ("tangent", "port_projection"):
        raise TMCError("initial_guess must be tangent or port_projection", code="invalid_input")
    if type(saved_load_only_anchor) is not bool:
        raise TMCError("saved_load_only_anchor must be boolean", code="invalid_input")
    if saved_load_only_anchor and (path_mode != "load_only" or not initial_parameter or initial_state is None):
        raise TMCError("saved_load_only_anchor requires a nonzero load-only saved state", code="invalid_input")
    if initial_parameter and (initial_state is None or (path_mode != "ordered_cycle" and not saved_load_only_anchor)):
        raise TMCError("nonzero initial_parameter requires an ordered-cycle saved state", code="invalid_input")
    if path_mode == "load_only" and (levels[0] != (initial_parameter if saved_load_only_anchor else 0)
                                      or np.any(np.diff(levels) <= 0)):
        raise TMCError("stage targets must start at initial_parameter and strictly increase" if saved_load_only_anchor
                       else "stage targets must start at zero and strictly increase", code="invalid_input")
    if path_mode == "ordered_cycle" and (levels[0] != initial_parameter or np.any(levels < 0)
                                         or np.any(np.diff(levels) == 0)):
        raise TMCError(("cycle targets must start at zero, be nonnegative and have no adjacent duplicates" if initial_parameter == 0
                        else "cycle targets must start at initial_parameter, be nonnegative and have no adjacent duplicates"),
                       code="invalid_input")
    if path_mode == "ordered_cycle" and (not np.any(np.diff(levels) < 0)
                                         or levels[-1] >= levels.max()):
        raise TMCError("ordered_cycle must include unloading and end below its loading peak",
                       code="invalid_input")
    lift_origin = _vector(np.zeros(model.ndof) if lift_origin is None else lift_origin, model.ndof, "lift_origin")
    lift_shape = _vector(np.zeros(model.ndof) if lift_shape is None else lift_shape, model.ndof, "lift_shape")
    probe = prescribed_body is not None
    if probe:
        if (not isinstance(prescribed_body, dict)
                or set(prescribed_body) != {"nodes", "d_hold", "zero_dofs", "background_dofs"}):
            raise TMCError("invalid prescribed body contract", code="constraint_conflict")

        def indices(value, limit):
            raw = np.asarray(value)
            if (raw.ndim != 1 or (raw.size and raw.dtype.kind not in "iu")
                    or np.any(raw < 0) or np.any(raw >= limit)
                    or len(np.unique(raw)) != len(raw)):
                raise TMCError("invalid prescribed body indices", code="constraint_conflict")
            return raw.astype(np.int64)

        nodes = indices(prescribed_body["nodes"], model.ndof//2)
        zero = indices(prescribed_body["zero_dofs"], model.ndof)
        background = indices(prescribed_body["background_dofs"], model.ndof)
        body_x, body_y = 2*nodes, 2*nodes+1
        body_dofs = np.union1d(body_x, body_y)
        held_mean = _positive_scalar(prescribed_body["d_hold"], "d_hold")
        expected_shape = np.zeros(model.ndof)
        expected_shape[body_x] = 1.
        overlap = np.intersect1d(zero, body_dofs)
        if (not len(nodes) or path_mode != "load_only" or initial_parameter != 0
                or target_origin != 0 or saved_load_only_anchor or initial_state is None or k_out != 0
                or not np.array_equal(np.union1d(zero, body_dofs), model.fixed_dofs)
                or not np.all(np.isin(background, zero)) or np.any(background % 2 != 1)
                or not np.all(np.isin(overlap, np.intersect1d(body_y, background)))
                or np.any(b_in[body_dofs]) or np.any(b_out[body_dofs])
                or np.any(lift_origin) or not np.array_equal(lift_shape, expected_shape)):
            raise TMCError("guided body conflicts with the fixed model or probe path", code="constraint_conflict")
    elif np.any(lift_origin[model.fixed_dofs]) or np.any(lift_shape[model.fixed_dofs]):
        raise TMCError("average-control supports must remain at zero", code="constraint_conflict")

    def mean_offsets(s):
        return (-held_mean,) if probe else (-target_origin, -s)

    def mean_target(s):
        return held_mean if probe else target_origin+s

    fresh_anchor_required = probe or bool(initial_parameter)
    with np.errstate(over="ignore", invalid="ignore"):
        anchor_lift = lift_origin.copy() if initial_parameter == 0 else lift_origin+initial_parameter*lift_shape
    if initial_state is None:
        initial = SplitDisplacement(lift_origin, np.zeros(model.ndof))
    else:
        if (not isinstance(initial_state, SplitDisplacement) or initial_state.ndof != model.ndof
                or not _bitwise_equal(initial_state.lift, anchor_lift)
                or np.any(initial_state.fluctuation[model.fixed_dofs])):
            raise TMCError("warm state must preserve supplied lift and fixed zero fluctuation", code="constraint_conflict")
        initial = initial_state.copy()
    assembly = assemble_split if assembler is None else assembler
    if not callable(assembly) or (on_accept is not None and not callable(on_accept)):
        raise TMCError("assembler and callback must be callable", code="invalid_input")
    started = perf_counter()
    state_u, state_R, state_s, state_K = initial.copy(), initial_R, initial_parameter, None
    accepted, trials, failures, history, linear_solves = [], [], [], [], []
    failure, maximum_depth = None, 0
    b_free = b_in[model.free]
    if initial_guess == "port_projection":
        port_norm_squared = float(b_free @ b_free)
        if not np.isfinite(port_norm_squared) or port_norm_squared <= 0:
            raise TMCError("port projection requires a finite positive weight norm", code="invalid_input")
    pivot = model.free[int(np.argmax(np.abs(b_free)))]
    times = dict(kernel_calls=0, successful_kernel_calls=0, kernel_and_transfer=0.,
                 assembly=0., sparse_solve=0., callback=0., all_assembly_attempts_wall=0.)

    def clock():
        if perf_counter()-started > settings.time_limit_seconds:
            raise TMCError("split average path wall-time budget exceeded", code="time_limit")

    def evaluate(state, tangent):
        clock()
        begin = perf_counter()
        times["kernel_calls"] += 1
        try:
            K, internal, fields = assembly(model, state, tangent=tangent)
        finally:
            times["all_assembly_attempts_wall"] += perf_counter()-begin
        times["successful_kernel_calls"] += 1
        for key in ("kernel_and_transfer", "assembly"):
            times[key] += fields["timing_seconds"][key]
        if not np.isfinite(internal).all() or not np.isfinite(fields["J"]).all():
            raise TMCError("split average fields are nonfinite", code="nonfinite")
        if np.any(fields["J"] <= 0):
            raise TMCError("all determinants must be positive", code="invalid_J")
        clock()
        return K, internal, fields

    def split_state(lift, w):
        try:
            return SplitDisplacement(lift, w)
        except (ValueError, OverflowError) as error:
            raise TMCError("split average candidate is nonfinite", code="nonfinite") from error

    def impose(w, s):
        with np.errstate(over="ignore", invalid="ignore"):
            lift = lift_origin.copy() if s == 0 else lift_origin+s*lift_shape
        return split_state(lift, w)

    def feasible(state, s):
        w = state.fluctuation.copy()
        before = _dot((state.lift, w), b_in, *mean_offsets(s))
        w[pivot] -= before/b_in[pivot]
        result = split_state(state.lift, w)
        after = _dot((result.lift, result.fluctuation), b_in, *mean_offsets(s))
        bound = settings.constraint_tolerance*max(abs(mean_target(s)), settings.displacement_scale_floor)
        if abs(after) > bound:
            raise TMCError("split average feasibility failed", code="constraint_failure",
                           details=dict(constraint_residual=after, constraint_bound=bound))
        return result, before, after

    def measure(state, R, s, internal):
        q_in = _dot((state.lift, state.fluctuation), b_in)
        q_out = _dot((state.lift, state.fluctuation), b_out)
        actuator, spring = b_in*R, k_out*b_out*q_out
        residual = internal+spring-actuator
        dscale = max(abs(mean_target(s)), settings.displacement_scale_floor)
        floor = settings.force_scale_floor_factor*force_scale_per_length*dscale
        norms = [float(np.linalg.norm(v[model.free])) for v in (internal, actuator, spring)]
        scale = max(*norms, floor)
        error = _dot((state.lift, state.fluctuation), b_in, *mean_offsets(s))
        if not np.isfinite(residual).all() or not np.isfinite(scale) or scale <= 0 or not np.isfinite(R):
            raise TMCError("split average forces are nonfinite", code="nonfinite")
        return dict(d=s, physical_mean_target_mm=mean_target(s), target_origin=target_origin,
                    R_input=R, q_in=q_in, q_out=q_out, constraint_residual=error,
                    displacement_scale=dscale, constraint_bound=settings.constraint_tolerance*dscale,
                    residual_scale=scale, force_scale_floor=floor,
                    free_force_residual_norm=float(np.linalg.norm(residual[model.free])),
                    relative_residual=float(np.linalg.norm(residual[model.free]))/scale,
                    input_force=actuator, spring_force_on_structure=-spring, force_residual=residual)

    def metrics(state, R, s, internal, fields):
        measured = measure(state, R, s, internal)
        support = np.zeros(model.ndof)
        support[model.fixed_dofs] = measured["force_residual"][model.fixed_dofs]
        balance = (support+measured["input_force"]+measured["spring_force_on_structure"]).reshape(-1, 2).sum(axis=0)
        balance_scale = max(sum(float(np.linalg.norm(v)) for v in
                                (support, measured["input_force"], measured["spring_force_on_structure"])),
                            measured["residual_scale"])
        measured.update(support_reaction=support, internal_force=internal.copy(),
                        material_internal_force=np.bincount(model.edofs.ravel(), weights=fields["material_residual"].ravel(), minlength=model.ndof),
                        regularization_internal_force=np.bincount(model.edofs.ravel(), weights=fields["regularization_residual"].ravel(), minlength=model.ndof),
                        J=fields["J"].copy(), minimum_J=float(fields["J"].min()),
                        global_force_balance=balance, global_force_balance_scale=balance_scale,
                        relative_global_force_balance=float(np.linalg.norm(balance))/balance_scale,
                        output_spring_energy=.5*k_out*measured["q_out"]**2,
                        output_spring_generalized_force=-k_out*measured["q_out"])
        if not all(np.isfinite(measured[key]).all() for key in
                   ("material_internal_force", "regularization_internal_force", "global_force_balance",
                    "global_force_balance_scale", "relative_global_force_balance", "output_spring_energy",
                    "output_spring_generalized_force")):
            raise TMCError("split average component/balance metrics are nonfinite", code="nonfinite")
        return measured

    def step(K, rhs_force, rhs_mean, phase, s, iteration=None):
        clock()
        _, free, augmented = _kkt(K, model, b_in, b_out, k_out)
        begin = perf_counter()
        try:
            dw, dR, row = _linear_solve(augmented, rhs_force, rhs_mean, free, b_free,
                                      phase=phase, target=mean_target(s), newton_check=iteration)
        finally:
            times["sparse_solve"] += perf_counter()-begin
        row.update(factorization="general sparse LU", symmetrized=False, stage_parameter=s)
        linear_solves.append(row)
        clock()
        return dw, dR, row

    def newton(start, R, old_s, K, s):
        candidate = impose(start.fluctuation, s)
        if s != old_s:
            if K is None:
                K, _, _ = evaluate(start, True)
            delta_L = candidate.lift-start.lift
            delta_q_out = _dot((candidate.lift, -start.lift), b_out)
            force_rhs = -(K@delta_L+k_out*b_out*delta_q_out)[model.free]
            mean_rhs = -_dot((candidate.lift, candidate.fluctuation), b_in, *mean_offsets(s))
            dw, dR, row = step(K, force_rhs, mean_rhs, "predictor", s)
            w = start.fluctuation.copy()
            if initial_guess == "port_projection":
                w[model.free] += mean_rhs*b_free/port_norm_squared
                row.update(displacement_mode=initial_guess, applied_dw=False, applied_dR=True)
            else:
                w[model.free] += dw
            candidate, before, after = feasible(impose(w, s), s)
            R += dR
            row.update(mean_error_before_projection=before, mean_error_after_projection=after)
        for iteration in range(1, settings.max_checks+1):
            K, internal, fields = evaluate(candidate, True)
            measured = measure(candidate, R, s, internal)
            history.append({k: measured[k] for k in ("d", "R_input", "q_in", "q_out", "constraint_residual", "constraint_bound", "relative_residual", "residual_scale")}
                           | dict(newton_check=iteration, minimum_J=float(fields["J"].min()), state_sha256=state_hash(candidate)))
            if (measured["relative_residual"] <= settings.tolerance
                    and abs(measured["constraint_residual"]) <= measured["constraint_bound"]):
                result = metrics(candidate, R, s, internal, fields)
                result["newton_checks"] = iteration
                return candidate, R, K, result
            if fresh_anchor_required and not accepted and old_s == s == initial_parameter:
                raise TMCError("saved continuation anchor failed its fresh equilibrium check",
                               code="initial_state_not_equilibrated")
            if abs(measured["constraint_residual"]) > measured["constraint_bound"]:
                raise TMCError("split mean constraint failed", code="constraint_failure")
            if iteration == settings.max_checks:
                raise TMCError("Newton base-check limit reached", code="newton_limit")
            r = measured["force_residual"][model.free]
            dw, dR, row = step(K, -r, -measured["constraint_residual"], "corrector", s, iteration)
            scale = measured["residual_scale"]
            phi = .5*float(np.dot(r/scale, r/scale))
            accepted_trial = False
            for backtrack in range(settings.max_backtracks+1):
                factor = 2.**(-backtrack)
                w = candidate.fluctuation.copy()
                w[model.free] += factor*dw
                trial_R = R+factor*dR
                record = dict(target_displacement=mean_target(s), stage_parameter=s, newton_check=iteration,
                              factor=factor, fixed_residual_scale=scale, base_phi=phi, accepted=False)
                try:
                    trial, before, after = feasible(impose(w, s), s)
                    _, trial_internal, trial_fields = evaluate(trial, False)
                    trial_measured = measure(trial, trial_R, s, trial_internal)
                    trial_r = trial_measured["force_residual"][model.free]
                    trial_phi = .5*float(np.dot(trial_r/scale, trial_r/scale))
                    if not np.isfinite(trial_phi):
                        raise TMCError("trial merit is nonfinite", code="nonfinite")
                    record.update(phi=trial_phi, minimum_J=float(trial_fields["J"].min()),
                                  mean_error_before_projection=before, constraint_residual=after, R_input=trial_R)
                    if trial_phi <= (1-2*settings.armijo_c*factor)*phi:
                        record["accepted"] = accepted_trial = True
                        candidate, R = trial, trial_R
                    else:
                        record["reason"] = "armijo_insufficient_decrease"
                except (KernelError, TMCError) as error:
                    if getattr(error, "code", None) == "time_limit":
                        raise
                    record["reason"] = getattr(error, "code", "trial_error")
                trials.append(record)
                if accepted_trial:
                    break
            if not accepted_trial:
                raise TMCError("all bounded backtracking factors rejected", code="backtracking_failed")
        raise AssertionError("unreachable")

    def advance(s, depth, original, original_index, leg):
        nonlocal state_u, state_R, state_s, state_K, maximum_depth
        before, before_R, before_s, before_K = state_u.copy(), state_R, state_s, state_K
        maximum_depth = max(maximum_depth, depth)
        try:
            solved, R, K, measured = newton(before, before_R, before_s, before_K, s)
        except (KernelError, TMCError) as error:
            assert (_bitwise_equal(state_u.lift, before.lift) and _bitwise_equal(state_u.fluctuation, before.fluctuation)
                    and _bitwise_equal(np.array([state_R]), np.array([before_R])) and state_s == before_s and state_K is before_K)
            code = getattr(error, "code", "numerical_failure")
            failures.append(dict(from_displacement=before_s, attempted_displacement=s, from_R_input=before_R,
                                 depth=depth, code=code, reason=str(error), rollback_bitwise_equal=True))
            if ((probe and not accepted and before_s == s == initial_parameter)
                    or code in ("time_limit", "constraint_failure") or depth >= settings.max_bisections
                    or abs(s-before_s)/2 < settings.minimum_increment*(1-1e-12)):
                raise
            advance(before_s+(s-before_s)/2, depth+1, original, original_index, leg)
            advance(s, depth+1, original, original_index, leg)
            return
        state_u, state_R, state_s, state_K = solved.copy(), float(R), float(s), K
        record = dict(measured, u_lift=solved.lift.copy(), u_fluctuation=solved.fluctuation.copy(),
                      u_display=solved.u_display, state_representation=STATE_SCHEMA, state_sha256=state_hash(solved),
                      original_target_displacement=original, is_original_target=s == original,
                      bisection_depth=depth, elapsed_seconds=perf_counter()-started)
        record.update(original_target_index=original_index, leg=leg)
        if probe:
            record.update(body_q_mm=s, input_mean_mm=record["q_in"],
                          probe_anchor=not accepted)
        accepted.append(record)
        if on_accept is not None:
            begin = perf_counter()
            try:
                on_accept(deepcopy(record))
            except OSError as error:
                raise TMCError(str(error), code="persistence_failure") from error
            finally:
                times["callback"] += perf_counter()-begin
        clock()

    try:
        _check_support(model)
        for index, s in enumerate(levels):
            leg = ("resume_origin" if initial_parameter else "origin") if index == 0 else "loading" if s > levels[index-1] else "unloading"
            advance(float(s), 0, float(s), index, leg)
    except (KernelError, TMCError) as error:
        failure = dict(code=getattr(error, "code", "numerical_failure"), reason=str(error))
    times["total"] = perf_counter()-started
    result = dict(status="success" if failure is None else "failed", target_reached=failure is None,
                target_displacement=float(levels[-1]), reached_displacement=state_s,
                target_origin=target_origin, physical_mean_target_mm=mean_target(float(levels[-1])),
                u_lift=state_u.lift.copy(), u_fluctuation=state_u.fluctuation.copy(), u_display=state_u.u_display,
                R_input=state_R, state_representation=STATE_SCHEMA, state_sha256=state_hash(state_u),
                target_metrics=deepcopy(accepted[-1]) if failure is None else None,
                last_accepted_state=deepcopy(accepted[-1]) if accepted else None, failure=failure,
                accepted_steps=accepted, trials=trials, failed_attempts=failures, newton_history=history,
                linear_solve_diagnostics=linear_solves, maximum_bisection_depth=maximum_depth, timing_seconds=times,
                lift_origin=lift_origin.copy(), lift_shape=lift_shape.copy(), initial_u_lift=initial.lift.copy(),
                initial_u_fluctuation=initial.fluctuation.copy(), initial_R=initial_R,
                b_in=b_in.copy(), b_out=b_out.copy(), k_out=k_out, force_scale_per_length=force_scale_per_length,
                input_force_sign="actuator_on_model", lift_scheme="affine_geometric_origin_v1",
                scope="split average-port numerical path; independent HP and task validation required")
    if path_mode == "ordered_cycle":
        completed = failure is None
        result.update(path_mode=path_mode, path_completed=completed,
                      loading_peak_reached=any(row["is_original_target"] and row["d"] == float(levels.max())
                                               for row in accepted),
                      unload_endpoint_reached=completed)
    if initial_guess != "tangent":
        result["initial_guess"] = initial_guess
    if initial_parameter:
        result["initial_parameter"] = initial_parameter
    if probe:
        result.update(body_q_targets_mm=levels.tolist(), reached_body_q_mm=state_s,
                      input_hold_mm=held_mean, scope="guided rigid-x prescribed probe; no bearing/release qualification")
    return result
