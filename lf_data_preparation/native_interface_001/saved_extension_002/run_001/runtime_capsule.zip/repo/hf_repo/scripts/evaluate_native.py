"""Evaluate one ordinary native geometry/task and print its compact response."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hf_eval.native_evaluate import evaluate_native


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, help="Base for relative input/output paths; otherwise cwd")
    parser.add_argument("--geometry", type=Path, help="Required for zero start; otherwise saved source geometry")
    parser.add_argument("--task", type=Path, help="Required for zero start; otherwise saved original task")
    parser.add_argument("--saved-result", type=Path, help="Original saved result to continue")
    parser.add_argument("--extend-path", action="store_true", help="Explicit --task appends targets after a completed saved terminal state")
    parser.add_argument("--selected-state-index", type=int, help="Accepted row index; paired with --saved-result")
    parser.add_argument("--output", type=Path, required=True, help="New evaluation directory")
    parser.add_argument("--targets", type=float, nargs="+", help="Full task path for zero start, or exact original-task suffix for saved continuation; otherwise inherited")
    parser.add_argument("--time-limit", type=float, default=180., help="Controller limit, not total CLI wall time")
    parser.add_argument("--minimum-increment", type=float, help="Zero-start increment; saved continuation inherits parent and forbids an override")
    parser.add_argument("--response-mode", choices=("complete", "mechanical"), help="Otherwise zero-start complete or saved parent option")
    parser.add_argument("--tangent-mode", choices=("full", "chunk256"), help="Otherwise zero-start full or saved parent option")
    parser.add_argument("--initial-guess", choices=("tangent", "port_projection"), help="Otherwise zero-start tangent or saved parent option")
    args = parser.parse_args()
    try:
        response = evaluate_native(args.geometry, args.task, args.output, repo_root=args.repo,
            targets=args.targets, time_limit_seconds=args.time_limit,
            minimum_increment=args.minimum_increment, response_mode=args.response_mode,
            tangent_mode=args.tangent_mode, initial_guess=args.initial_guess,
            saved_result=args.saved_result,selected_state_index=args.selected_state_index,
            **({"extend_path":True} if args.extend_path else {}))
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"Native evaluation could not save its response: {error}\n")
    print(json.dumps(response, indent=2, ensure_ascii=False, allow_nan=False))
    return 0 if response["status"] == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
