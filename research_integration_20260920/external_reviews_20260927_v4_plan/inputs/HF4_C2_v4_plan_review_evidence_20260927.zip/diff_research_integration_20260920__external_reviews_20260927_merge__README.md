--- main/research_integration_20260920/external_reviews_20260927_merge/README.md
+++ plan/research_integration_20260920/external_reviews_20260927_merge/README.md
@@ -26,4 +26,4 @@
 
 审查者的环境为 JAX／jaxlib 0.9.0.1。在该环境中，补偿运动学的 22 项测试在编译阶段报错 `INVALID_ARGUMENT: No such compile option: 'xla_cpu_ftz'`；P1 的 279 项与其余 6 项算术测试通过。审查者没有为求通过而删去严格编译选项。
 
-这说明候选内核依赖一个接受 `xla_cpu_ftz` 的 JAX／XLA 版本：锁定的 JAX 0.11.0 接受它（全量 1291 项通过），旧版本会在编译时直接报错，而不会静默改用宽松的编译设置（按设计失败即停，没有回退）。这不是锁定环境中的失败。之后若要支持其他 JAX 版本，需要单独处理，不能移除这项选项了事。
+这说明候选内核需要一个接受 `xla_cpu_ftz` 的 JAX／XLA：已测试的两个环境中，审阅者的 JAX 0.9.0.1 在编译时直接报错，已记录的锁定 JAX 0.11.0 接受它（全量 1291 项通过）；报错时不会静默改用宽松的编译设置（按设计失败即停，没有回退）。其他版本未测试，这里不做推断。这不是锁定环境中的失败；之后若要支持其他 JAX 版本，需要单独处理，不能移除这项选项了事。
