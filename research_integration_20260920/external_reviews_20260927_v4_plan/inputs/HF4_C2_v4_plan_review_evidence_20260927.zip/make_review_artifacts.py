from pathlib import Path
import json,hashlib,zipfile
base=Path('/mnt/data'); work=base/'v4_plan_review_work'; tree=work/'tree'
sections=[
 ('docs/HF4_C2_V4_CHANGE_LIST_AND_RETEST_PLAN.md',[(1,84)]),
 ('hf_repo/src/hf_eval/split_affine.py',[(1,22),(91,104),(124,147),(322,365)]),
 ('hf_repo/src/hf_eval/displacement.py',[(94,102)]),
 ('hf_repo/src/hf_eval/tmc.py',[(167,176)]),
 ('hf_repo/scripts/run_contact_c2.py',[(15,21),(64,91)]),
 ('hf_repo/scripts/contact_c2_launch_p1.py',[(25,32),(152,169),(179,201),(271,292),(323,353),(394,408),(436,444)]),
 ('hf_repo/scripts/audit_contact_c2.py',[(18,37),(78,91),(214,259),(427,464),(475,484),(508,549)]),
 ('hf_repo/scripts/validate_contact_c2_stable_f.py',[(249,274)]),
 ('hf_repo/src/hf_eval/split_kernel_compensated.py',[(19,27),(169,172)]),
 ('hf_repo/tests/test_split_affine.py',[(1,15),(34,63)]),
 ('hf_repo/scripts/audit_contact_c2_readback.py',[(1,6),(30,48)]),
]
text=['# v4 计划审查：原始源码与计划定位摘录\n',
'来源：本轮上传的 `Compliant-TO-TMC-claude-hf4-c2-v4-plan.zip`，ZIP 注释为 `a652a3fe5e9ccbc1b61ad0e90713bd01eb3a2da4`。以下行号是原文件行号。摘录不是新实现，也不是运行结果。\n']
for path,ranges in sections:
 lines=(tree/path).read_text(encoding='utf-8').splitlines()
 text += ['\n## '+path+'\n', '原字节 SHA-256：`'+hashlib.sha256((tree/path).read_bytes()).hexdigest()+'`\n']
 for first,last in ranges:
  text += [f'\n### 第 {first}–{last} 行\n\n```text\n']
  text += [f'{i:4d} | {lines[i-1]}\n' for i in range(first,min(last,len(lines))+1)]
  text += ['```\n']
excerpt=base/'HF4_C2_v4_plan_source_excerpts_20260927.md'; excerpt.write_text(''.join(text))
comparison=json.loads((work/'snapshot_comparison.json').read_text())
checks=json.loads((work/'static_checks.json').read_text())
verification=base/'HF4_C2_v4_plan_verification_20260927.json'
verification.write_text(json.dumps({'snapshot_comparison':comparison,'static_checks':checks},ensure_ascii=False,indent=2)+'\n')
report=r'''# HF4-C2 v4 最小变更与有界复验计划审查

日期：2026-09-27。审查对象：本轮上传的 main (3) 与 v4-plan 两份 ZIP；已审记录分支 ZIP 用作合并内容对照。独立审阅，不修改源码、不执行 Git 合并、不运行新 FE。

## 1. 决策摘要

合并内容验收可关闭。v4 的技术方向可以接受，但计划不能按原文直接冻结：第 22 行与第 44 行构成协议 SHA 与启动守卫 SHA 的相互引用。该问题阻断按原文冻结，不阻断已完成的 main 集成，也不要求重新设计力学求解器。

| 决定 | 审查意见 |
| --- | --- |
| V1 | 原则同意新增隔离模块、一行换核、复用冻结审计及不纳入空支座补丁；先消除相互引用 |
| V2 | 建议允许在同一工作分支落实修正、实现有限功能、执行已批准的普通回归/算术/替身测试，形成冻结候审版本；不是实际路径运行授权 |
| V3 | 本轮不视为授权。待 v4 实现、协议身份、测试结果及只读启动检查核对后，由所有者明确授权一次真实路径及一次独立审计 |
| V4 | 支持外置大载荷并保留可恢复原始证据；轻量清单留仓。无须为了本轮另建存储平台或先公开发布全部资产 |

HF5 H1–H4 仍然分开决定。LF 本轮无修改事项，不重新生成候选。

## 2. 实际完成的核查与未完成的验证

实际执行：ZIP 原字节逐文件比较；33 个 v3 实现文件 SHA-256 重算；两份新归档审查输入与当前会话附件逐字节比较；计划及有关调用链静态阅读；在内存中构造一行替换后的文本并做 AST 语法解析；读取已有计时及结果摘要。

没有执行：HF 源码导入、pytest、FE 内核求值、平衡路径、80/120 位数值审计、依赖安装、源码补丁、Git 合并或远端查询。内存中的替换文本没有写成新模块或导入执行。

ZIP 注释只能说明上传快照标注的提交，不能独立证明 Git 双亲或推送成功。本次确认的是上传内容，远端实时状态及 Git 操作过程仍依据执行者报告。

## 3. 文件树与归档

| 比较 | 不变 | 新增 | 修改 | 删除 |
| --- | ---: | ---: | ---: | ---: |
| 已审记录分支 754a7a2 → main 7e007ca | 2959 | 0 | 0 | 0 |
| main 7e007ca → 计划分支 a652a3f | 2956 | 5 | 3 | 0 |

三个修改文件：根 README、`docs/HF4_C2_P1_AND_STABLE_F_REPORT.md`、`research_integration_20260920/external_reviews_20260927_merge/README.md`。五个新增文件：v4 计划、后合并审查归档 README、输入清单以及两份审查输入。没有新增或改写 `hf_repo` 实现/测试/协议，也没有新 v4 FE 产物进入快照。

v3 的 33 个实现文件全部原字节匹配。两份新归档审查输入的大小与 SHA 均匹配清单，且与当前会话附件原字节相同。JAX 说明已收窄为两个已记录的测试环境，未再泛化未测试版本；本轮未重做兼容性测试。

## 4. 支持采纳的实现设计

### 4.1 一行换核副本在本轮合理

`split_affine.py:14–20` 的力学求值通过该模块的 `assemble_split` 名称调用，旧内核由第 19 行直接导入。`evaluate()` 也是调用这个名称。其余被复用的支承检查、线性步、状态哈希等不负责 C2 的旧核力学求值。因此新副本只替换这一条 import，可以在不改动控制器逻辑的情况下显式切换本次路径内核。

这只是代码调用和接口层面的结论，不是新路径数值验证。Newton 检查次数、接受态和二分序列可以因算术改变而变化；必须保持七个原目标与控制规则，但不应要求 v4 恰好重复 v3 的 21 个接受态。

不建议为避免一次 392 行副本而重构全部冻结求解器；也不应将本次做法外推为所有未来版本永久只能复制。当前有限修复无需新插件框架。

### 4.2 审计复用成立，但只复用数值与记录辅助函数

`audit_contact_c2.py:214–259` 对保存量使用独立 Decimal 参考，80/120 位和原阈值均可保留。`validate_model` 与 `load_controller` 针对当前细网格仍适用。

原 `validate_protocol` 在第 78–91 行固定了旧 schema 和三个 case；`load_run` 在第 450–458 行固定了旧 run schema 和旧核源码名。新入口需要替换这些 v3 身份装载部分，不得直接把新结果冒充 v3 输入。

`audit_contact_c2_readback.py` 可作为“导入原函数”的结构参考，但其公开复读来源豁免不能自动变成 v4 的执行准入豁免。沿用 v3 准入时，仍需要本机具备并核验其所要求的资料；这不是本次新增要求。

### 4.3 空支座补丁不纳入 v4 是正确收缩

`split_affine.py:14` 导入的是 `displacement._check_support`，后者第 101 行已经有空/不足三个自由度的短路。先前补丁作用于 `tmc.py:175` 的另一函数。该修补不参与本次 C2 路径，因此不应为其改变旧冻结文件。

接受执行者对上轮建议的修正。以后确实使用该入口且需要修改其实现身份时再处理；不据此要求 HF5 必须采用力控制。

## 5. 必须解决的冻结问题

### B1：协议与守卫的哈希相互引用

**证据**：计划第 22 行拟在 v4 守卫内设置 v4 协议 SHA；第 44 行又将 v4 守卫纳入协议的 `implementation_sha256`。

**影响**：先写守卫 SHA 到协议会改变协议 SHA；再把新协议 SHA 写回守卫又改变守卫 SHA。常规“写实现—算哈希—冻结协议”的步骤不能闭合。这属于尚未实现的冻结设计冲突，不是已运行内核的缺陷。

**最小处理**：沿用现有 P1 的分层方式。协议绑定求解器、候选核、审计及实际依赖；含协议 SHA 常量的启动守卫不再反向列入该协议的实现哈希字典。协议冻结后写入守卫常量，再将守卫/P1 复用模块/启动入口的原字节身份与协议身份一起记录在协议外的启动计划及已审提交中，父子握手和回执继续绑定它们。无需放松原字节比较，也无需增加签名系统。

源码依据：`contact_c2_launch_p1.py:26` 固定旧协议 SHA；`configs/contact_c2_v3.json` 的 33 项实现清单没有 P1 文件；`contact_c2_launch_p1.py:199–200` 将它们另行加入启动绑定，第 349–353、394–408、436–440 行将启动计划和回执串联。

**最小验证**：能按确定顺序冻结并一次通过只读计划检查；任意改动被绑定的内核或守卫后，计划与其外部身份不一致时应被发现。不要为了闭合循环而对源文件特殊删去常量行后再做所谓“原字节”哈希。

该修正可直接随 V2 实施，不必先单独提交文档再等待一次完整审查。

## 6. 实施/运行前需要写清的范围，不扩展功能

### P1：预算与停止规则按现有代码解释

原协议已包含三种预算：

| 层次 | 上限 | 解释 |
| --- | ---: | --- |
| 求解器内部墙钟 | 300 s | `solver.time_limit_seconds`；包括内部核调用、线性求解及接受回调耗时 |
| 求解子进程外部墙钟 | 700 s | 外部强制上限，不会覆盖内部 300 s |
| 独立审计子进程 | 1200 s | 与求解分开计量 |

计划声称 solver 与 v3 相同，所以内部 300 s 已被隐含继承；应在预算表中显式列出，不能误读为求解器可使用全部 700 s。无需改变任何数值。

“不自动重试”指不另开一次真实路径、改参数或扩大资源重跑，不禁止旧控制器内原已声明的 Armijo 回溯和最多八层二分。`split_affine.py:322–343` 正是在一次路径内部执行这些动作。

“第一个独立审计失败即停”发生在求解后的审计阶段，不能描述成 Decimal 检查在求解时逐步实时阻止后续 Newton。无需为一句停止说明新建在线高精度审计。

### P2：硬超时保留的是接受记录，不自动是已认证有效前缀

计划第 63 行的“保留有效前缀”需要收窄。原审计装载器第 481–482 行要求完整 controller/completion；硬终止可能只留下 NPZ 与逐态记录。原 P1 `_receipt` 第 219–220 行还拒绝失败或超时的前一子进程。

最小处理仅改口径：超时/失败保留所有已落盘接受态和日志；只有通过独立审计的连续前缀才称为“已验证可比较前缀”。未审计、缺完整记录或未完成的部分不计通过。不要求新增续算、恢复求解或不完整目录审计功能。

### P3：V2 测试不夹带新的真实研究路径

新增控制器测试可直接采用 `tests/test_split_affine.py` 的解析弹簧替身：其第 39–61 行替换 `assemble_split`，不调用实际 FE 核。runner/守卫也已有替身测试模式。普通已批准回归与算术/单元检查单列记录。

计划第 24 行的“小型合成模型路径行为”应明确为上述控制器替身，或者将实际 TMC 小路径留待明确授权；不能仅因为模型小或运行在 pytest 中就称为没有新 FE。当前不增加试跑 C2、预热 C2 路径或真实 HF5 任务。

### P4：所有生产量都属于新内核，JVP 编译设置不得遗漏

这已经是计划第 20 行的目标，实施时需要对具体调用核实，而非新增验证矩阵：求解、接受态回调、仅力/含切线和材料/正则 JVP 不应混用旧核。尤其独立构造的 JVP 编译入口需要相同严格选项，不能只在元数据记录。

已有可参考的实现为 `validate_contact_c2_stable_f.py:249–258`，它将 `kernel.COMPILER_OPTIONS` 传给 JVP 的 `jax.jit`。原 `run_contact_c1_r2.component_actions` 调用旧核，不直接用于新 runner。独立 Decimal 审计仍然不导入生产内核。

## 7. 成本证据及其边界

本轮轻量 ZIP 不带原独立 `mesh_h00625.*.receipt.json` 文件，但 `hf4_c2_diagnostics/summary_001/summary.json` 的 `/runs/4/external_execution/actions` 嵌入了其记录：solve 为 33.088052900042385 s，returncode=0；audit 为 200.02368759992532 s，returncode=1，无超时。后者是数值不通过，而非耗时失败。本次读取了该嵌入记录，未恢复外部原回执/日志并重新核验。

`hf4_c2_stable_f_validation/timing_001/timing.json` 是一个固定保存态的组装计时，1920 元、4074 自由度、每种五次重复。含切线中位数从 0.0196875 s 到 0.1020093 s，约 5.18 倍；仅力中位数从 0.0090631 s 到 0.0724779 s，约 8.00 倍。因此“每次组装统一慢五倍”不够精确。

“合计约五分钟”可保留为粗估，不能承诺。新路径的 Newton、回溯、二分、回调/JVP 和冷编译开销会改变实际耗时。当前证据没有要求增加预算，也无需为了估时先跑一次未经授权的路径。

## 8. 存储 V4

同意新大载荷置于 Git 外。最少保留：模型、初态、每个接受态 NPZ、完整 controller/逐态记录、80/120 位审计详情、轻量结果与日志回执；其中体积大的 controller/高精度 JSON 同样可以无损外置，不必仅外置 NPZ。

轻量清单注明原相对路径、字节数、SHA、归档文件/存放位置及恢复方法。移除工作树载荷前核对归档，至少完成一次空目录恢复的原字节检查；这是已有 S0 原则的轻量复用，不是新力学试验或新基础设施。只保存哈希而遗失原数组不能称为保留证据。公开 Release 发布不是此次路径运行的新增前置。

## 9. 阶段结论与下一步停止点

已完成：main 合并内容核对；v4 草案提交及技术方向审查。

尚未完成：v4 实现、修正后的无循环冻结身份、测试验收、真实细网格复验。

建议下一步到达：在现有工作分支落实 B1 及必要口径，新增限定模块/测试，形成 v4 冻结候审提交，提供差异清单、33 原文件原字节检查、新实现及协议绑定、实际测试命令与结果、只读启动计划，然后停止。

本轮不把建议转化为已发生的执行授权。V3 仍须所有者明确确认；不切换默认入口、不改 v3 历史 NOT_PASS、不运行 LF、不自动实施 HF5。新路径通过只说明本次算术修复在指定离散任务和既定门槛下成立，不证明 TMC 全面物理可靠、网格收敛或真实夹持器性能优选已完成。

## 10. 附件

- `HF4_C2_v4_plan_verification_20260927.json`：快照差异、全部 33 项哈希、两份归档核对、原回执嵌入记录和计时提取。
- `HF4_C2_v4_plan_source_excerpts_20260927.md`：计划及相关原代码行号摘录。
- `HF4_C2_v4_plan_review_evidence_20260927.zip`：本报告、上述证据、三份文档 diff 和报告打包脚本。
'''
reportpath=base/'HF4_C2_v4_plan_review_20260927.md'; reportpath.write_text(report)
zip_path=base/'HF4_C2_v4_plan_review_evidence_20260927.zip'
paths=[reportpath,excerpt,verification,work/'snapshot_comparison.json',work/'static_checks.json']+list(work.glob('diff_*'))
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.name)
 # This records artifact assembly only; no independent FE/test execution.
 z.write(Path(__file__),'make_review_artifacts.py')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [reportpath,excerpt,verification,zip_path]}
(work/'output_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False,indent=2))
