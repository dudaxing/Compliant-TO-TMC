--- main/docs/HF4_C2_P1_AND_STABLE_F_REPORT.md
+++ plan/docs/HF4_C2_P1_AND_STABLE_F_REPORT.md
@@ -164,5 +164,5 @@
 
 所有者转来合并审查后，本分支的已审版本 `6a40957` 以普通合并进入 `main`，合并提交为 `1729755`，保留全部分支提交；合并结果的树与 `6a40957` 相同。这次合并仅为集成：默认求解路径不变，C2 历史 `NOT_PASS` 不变，不授权新 FE，也不确认 HF5。输入与执行记录见 `research_integration_20260920/external_reviews_20260927_merge/`。
 
-审查者在 JAX／jaxlib 0.9.0.1 环境中运行时，补偿运动学的 22 项测试在编译阶段报 `No such compile option: 'xla_cpu_ftz'`；P1 的 279 项通过。候选内核需要一个接受该选项的 JAX／XLA（锁定的 0.11.0 满足）；旧版本会在编译时直接失败，没有回退，这是设计使然。
+审查者在 JAX／jaxlib 0.9.0.1 环境中运行时，补偿运动学的 22 项测试在编译阶段报 `No such compile option: 'xla_cpu_ftz'`；P1 的 279 项通过。候选内核需要一个接受该选项的 JAX／XLA：已测试的 0.9.0.1 不支持（编译时直接失败，没有回退，这是设计使然），已记录的锁定 0.11.0 通过；其他版本未测试，不做推断。
 
