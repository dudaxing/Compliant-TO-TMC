"""Independent arithmetic/inventory check of supplied C2 records. No FE/HP constitutive solve."""
from pathlib import Path
from decimal import Decimal,localcontext
import hashlib,json,collections,math,numpy as np
B=Path(__file__).resolve().parents[1]; R=B/'snapshots/Compliant-TO-TMC-main'; C=R/'hf4_c2_diagnostics'
rd=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=rd(R/'hf_repo/configs/contact_c2_v3.json'); result={'scope':'stored-vector arithmetic, actual file identities and statuses, not rerun of production solves or 80/120 constitutive evaluation'}
for name,digest in protocol['implementation_sha256'].items():assert sha(R/'hf_repo'/name)==digest
admission=rd(C/'saved_field_admission_r3.json');missing=[]
for name,h in admission['input_sha256_from_workspace_root'].items():
 p=R/name
 if not p.exists():missing.append(name)
 else:assert sha(p)==h,name
assert sorted(missing)==sorted(['hf0_audit/tmc/assembleKtFi.m.numbered.txt','hf0_audit/tmc/initializeFEA.m.numbered.txt'])
result['frozen_sources']={'implementation_files_matched':len(protocol['implementation_sha256']),'admission_entries':len(admission['input_sha256_from_workspace_root']),'available_admission_matched':len(admission['input_sha256_from_workspace_root'])-len(missing),'not_provided_historical_sources':missing}
counts=collections.Counter(); details=[];paths=[]; bound_keys=set(); binding_missing=set()
summary=rd(C/'summary_001/summary.json');srun={r['case_id']:r for r in summary['runs']}
with localcontext() as ctx:
 ctx.prec=120
 D=Decimal
 norm=lambda xs:sum((x*x for x in xs),D(0)).sqrt()
 for case in ['padding_2p5','outer_free','mesh_h00625']:
  run=C/'experiments'/case;a=rd(run/'audit.json');meta=rd(run/'metadata.json');stage=run/'stages/uniform_tmc';idx=rd(stage/'steps/index.json')['steps'];valid_prefix=True;npass=0;nchecks=0;goodchecks=0
  assert meta['protocol']==protocol and meta['protocol_sha256']==sha(R/'hf_repo/configs/contact_c2_v3.json')
  for source,h in a['input_and_helper_sha256'].items():
   p=(run/source).resolve()
   assert p.is_relative_to(R)
   if not p.exists():binding_missing.add(p.relative_to(R).as_posix());continue
   assert sha(p)==h,str(p);bound_keys.add(str(p))
  model=dict(np.load(stage/'model.npz',allow_pickle=False));top=model['top_y_dofs'] if 'top_y_dofs' in model else None
  for s,entry in zip(a['states'],idx):
   dp=run/s['detail_file'];assert sha(dp)==s['detail_sha256'];row=rd(dp)
   sp=stage/'steps'/entry['file'];assert sha(sp)==entry['sha256']
   npz=dict(np.load(sp,allow_pickle=False));ev=row['precision_evidence_decimal'];ref=[D(x) for x in ev['80']['internal_decimal']];hi=[D(x) for x in ev['120']['internal_decimal']];sf=D(row['measurements']['force_scale']);prod=[D(float(x)) for x in npz['internal_force']]
   relative=norm([x-y for x,y in zip(prod,ref)])/sf
   cross=norm([x-y for x,y in zip(ref,hi)])
   check={c['name']:c for c in row['checks']};target=D(check['production_vs_hp80_total_force']['value'])
   assert abs(relative-target)<=D('1e-100')+abs(target)*D('1e-65')
   good=True
   for ch in row['checks']:
    v,l=D(ch['value']),D(ch['limit']);rel=ch['relation']
    passed={'<=':v<=l,'<':v<l,'>=':v>=l,'>':v>l,'==':v==l}[rel]
    assert passed==(ch['status']=='pass'),ch
    good &= passed;nchecks+=1;goodchecks+=passed
   assert good==(row['status']=='pass')==(s['status']=='pass')
   valid_prefix &= good; assert bool(row['valid_prefix_comparable'])==valid_prefix==s['valid_prefix_comparable']
   if not valid_prefix:assert a['prefix']['states'][entry['index']]['normal_force'] is None
   npass+=good
   # Same saved HP reaction components, independent sum (no contact pressure interpretation).
   top_values=[D(x) for x in row['measurements']['top_weak_normal_reactions']]
   f=sum(top_values,D(0));assert abs(f-D(row['normal_force_raw']))<D('1e-65')
   details.append({'case':case,'state_id':row['state_id'],'d':row['parameter_s'],'status':row['status'],'checks':len(row['checks']),'relative_total_force_error_from_npz_and_hp80':str(relative),'hp80_hp120_total_vector_error_N':str(cross),'normal_force_signed_sum_N':str(f)})
   counts['states']+=1;counts['passed_states']+=good;counts['checks']+=len(row['checks']);counts['passed_checks']+=sum(c['status']=='pass' for c in row['checks'])
  assert len(idx)==a['summary']['accepted_states']==len(a['states']);assert npass==a['summary']['passed_states'];assert nchecks==a['summary']['independent_checks'];assert goodchecks==a['summary']['independent_checks_passed']
  prefix_count=sum(s['valid_prefix_comparable'] for s in a['states']);assert prefix_count==a['prefix']['prefix_length']
  paths.append({'case':case,'solver_status':rd(run/'result.json')['status'],'audit_status':a['status'],'states':len(idx),'passed':npass,'checks':nchecks,'passed_checks':goodchecks,'valid_prefix_length':prefix_count,'valid_prefix_last_d':a['states'][prefix_count-1]['parameter_s'],'original_targets_in_valid_prefix':sum(s['is_original_target'] and s['valid_prefix_comparable'] for s in a['states'])})
 # Independently recompute all saved arithmetic counterfactual errors against retained HP120 vector.
 v=rd(C/'force_precision_001/vectors.json')['variants'];record=rd(C/'force_precision_001/summary.json');sf=D(record['force_scale_N']);errors={}
 for name,vec in v.items():
  errors[name]={}
  for component,raw in vec.items():
   n=norm([D(x)-D(y) for x,y in zip(raw,v['exact_split_reference'][component])]);err=n/sf;claimed=D(record['variants'][name][component]['error_over_frozen_SF']);assert abs(err-claimed)<D('1e-100')+abs(claimed)*D('1e-75');errors[name][component]=str(err)
 result['precision_variant_errors_recomputed']=errors
 # Re-read stored split displacement without creating rounded summed state; check binary64 preservation.
 last=C/'experiments/mesh_h00625/stages/uniform_tmc/steps'/idx[-1]['file'];arrays=dict(np.load(last,allow_pickle=False))
 assert arrays['u_lift'].dtype==arrays['u_fluctuation'].dtype==np.float64
 result['terminal_displacement_authority']={'file':str(last.relative_to(R)),'u_lift_dtype':str(arrays['u_lift'].dtype),'u_fluctuation_dtype':str(arrays['u_fluctuation'].dtype),'stored_total_force_vector_entries':len(arrays['internal_force'])}
result.update(counts=dict(counts),paths=paths,state_rows=details,available_audit_inputs_matched=len(bound_keys),historical_missing_inputs=sorted(binding_missing),all_checks_passed=True)
assert result['counts']=={'states':59,'passed_states':58,'checks':1810,'passed_checks':1809}
# Byte-identical public readback detail duplicates are not merely similar scalar summaries.
port=C/'portability_readback_001/details';pairs=[]
for case in ['padding_2p5','mesh_h00625']:
 for p in sorted((port/case).glob('state_*.json')):
  orig=C/'experiments'/case/'audit_states'/p.name;assert p.read_bytes()==orig.read_bytes();pairs.append({'replayed_copy':p.relative_to(R).as_posix(),'original':orig.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(pairs)==40;result['public_readback_byte_identical_details']=len(pairs);result['public_readback_duplicate_bytes']=sum(x['bytes'] for x in pairs)
(B/'evidence/saved_evidence_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(B/'evidence/readback_duplicate_pairs.json').write_text(json.dumps(pairs,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['state_rows','precision_variant_errors_recomputed']},indent=2))
