"""Review-only archival plan and disposable slim-tree simulation. Original sources untouched."""
from pathlib import Path
import json,collections,shutil
B=Path(__file__).resolve().parents[1];R=B/'snapshots/Compliant-TO-TMC-main';inv=json.loads((B/'evidence/file_inventory_with_sha256.json').read_text())
# Units of migration are historical run/diagnostic directories, never a threshold-driven deletion list.
prefixes={
 'c2_runs':['hf4_c2_diagnostics/experiments/'],
 'c2_readback_details':['hf4_c2_diagnostics/portability_readback_001/details/'],
 'c1_runs':[p.relative_to(R).as_posix()+'/' for p in (R/'hf4_c1_results').iterdir() if p.is_dir() and p.name.startswith(('A0_','Aalpha_','TMC_'))],
 'c0_runs':['research_integration_20260920/results/'],
 'hf4_repair_raw':[p.relative_to(R).as_posix()+'/' for p in (R/'hf4_repair_results').iterdir() if p.is_dir() and (p.name.endswith('_audit') or p.name in ['split_preflight_001','retained_update_001'])],
 'hf4_original_raw':[p.relative_to(R).as_posix()+'/' for p in (R/'hf4_results').iterdir() if p.is_dir() and (p.name.endswith('_audit') or p.name.startswith('fixed_'))],
 # Keep all geometry in the conservative candidate. Optional further asset below not simulated.
}
plan=[];by=collections.Counter();kept=0;dst=B/'slim_tree_simulation/Compliant-TO-TMC-main'
for row in inv['files']:
 category=next((k for k,pp in prefixes.items() if any(row['path'].startswith(p) for p in pp)),None)
 copy=dict(row);copy['proposed_action']='EXTERNALIZE_LOSSLESS_RESTORE_ORIGINAL_PATH' if category else 'KEEP';copy['asset_group']=category
 plan.append(copy)
 if category:by[category]+=row['bytes']
 else:
  kept+=row['bytes'];d=dst/row['path'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/row['path'],d)
report={'original_bytes':inv['expanded_bytes'],'keep_bytes':kept,'externalize_bytes':sum(by.values()),'reduction_fraction':sum(by.values())/inv['expanded_bytes'],'categories_bytes':dict(by),'prefixes':prefixes,'status':'review-side candidate only; original tree and Git not modified; restore/asset publication not implemented','keep_all_hf_repo':True,'keep_all_geometry_dataset':True,'keep_all_root_documents_and_summaries':True,'optional_geometry_archive_further_bytes':sum(r['bytes'] for r in plan if r['path'].startswith('geometry_dataset/archive/')),'files':plan}
(B/'evidence/storage_migration_candidate.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))
