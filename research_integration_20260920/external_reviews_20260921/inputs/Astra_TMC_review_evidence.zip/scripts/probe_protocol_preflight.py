"""Intercept the actual C2 launcher immediately before subprocess start. No child/FE run."""
from pathlib import Path
import sys,json,runpy,importlib.util,tempfile,subprocess
from unittest.mock import patch
B=Path(__file__).resolve().parents[1];R=B/'snapshots/Compliant-TO-TMC-main';S=R/'hf_repo/scripts'
sys.path.insert(0,str(S));sys.path.insert(0,str(R/'hf_repo/src'))
import audit_contact_c2 as audit
p=json.loads((R/'hf_repo/configs/contact_c2_v3.json').read_text());results=[]
class BeforeChild(RuntimeError):pass
for changed in [False,True]:
 doc=json.loads(json.dumps(p))
 if changed:doc['solver']['tolerance']=1e-3
 with tempfile.TemporaryDirectory(prefix='protocol_probe_',dir=B) as temp:
  t=Path(temp);proto=t/'contact_c2_v3.json';proto.write_text(json.dumps(doc))
  record={'solver_tolerance':doc['solver']['tolerance'],'other_scientific_fields_unchanged':True,'child_launched':False}
  try:audit.validate_protocol(doc);record['auditor_validation']='accepted'
  except Exception as ex:record['auditor_validation']='rejected';record['auditor_error']=str(ex)
  def intercept(*args,**kwargs):
   record['launcher_reached_child_dispatch']=True;record['captured_command']=args[0]
   raise BeforeChild('review intercept: actual subprocess not executed')
  argv=[str(S/'run_contact_c2_isolated.py'),'--action','solve','--run',str(t/'runs/padding_2p5'),'--case','padding_2p5','--protocol',str(proto)]
  with patch.object(sys,'argv',argv),patch.object(subprocess,'run',intercept):
   try:runpy.run_path(str(S/'run_contact_c2_isolated.py'),run_name='__main__')
   except BeforeChild:pass
  results.append(record)
assert results[0]['auditor_validation']=='accepted' and results[1]['auditor_validation']=='rejected'
assert all(r['launcher_reached_child_dispatch'] for r in results)
(B/'evidence/protocol_preflight_probe.json').write_text(json.dumps({'scope':'synthetic protocol plus intercepted real launch flow; no child process, no FE, no original files changed','results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
