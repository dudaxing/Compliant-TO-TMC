# 上传源码逐行摘录

以下行号来自本次上传文件；原源码未修改。LF与HF根目录分别对应两个上传ZIP。运行结果不在这些摘录内，见evidence。

## LF — `src/dmftd/mechanism_case.py:47–64`

```text
47: # "contract_segment": the symmetry uy=0 constraint exactly as the benchmark contract states it
48: # (for the gripper only the material part x<=60 mm of the top edge).  "full_midline": uy=0 on
49: # every top-row node, so the half model equals a connected mirrored full model of the ersatz
50: # material (the soft jaw gap included).  The physical symmetry segment is unchanged either way.
51: SYMMETRY_POLICIES = ("contract_segment", "full_midline")
52: OUTPUT_SIGN_CONVENTION = ("q = b_output.T @ u is positive when the output port moves along the contract output "
53:                           "direction; gripper: the lower jaw port (x=80 mm, y in [28,30] mm) moving toward the "
54:                           "symmetry axis (+y) is closing")
55: 
56: 
57: @dataclass(frozen=True, slots=True)
58: class MechanismCase:
59:     """Grid, masks, supports, ports and provenance of one linear mechanism problem."""
60: 
61:     name: str
62:     nelx: int
63:     nely: int
64:     length_mm: float
```

## LF — `src/dmftd/mechanism_case.py:205–275`

```text
205: def inverter_case(benchmark: Mapping[str, Any], nelx: int, nely: int, *, formulation: str, nu: float,
206:                   thickness_mm: float) -> MechanismCase:
207:     """The frozen displacement-inverter half model exactly as the sealed M1-M4 code defines it.
208: 
209:     The contract symmetry segment covers the whole top edge, so ``contract_segment``
210:     and ``full_midline`` coincide for this case.
211:     """
212: 
213:     view = runtime_benchmark_v1_1(benchmark)
214:     geometry = build_masks(view, nelx, nely, case="inverter")
215:     return _build_case(name="inverter", benchmark=benchmark, view=view, geometry=geometry, formulation=formulation,
216:                        nu=nu, thickness_mm=thickness_mm, symmetry_policy="contract_segment",
217:                        fixed_dofs=project_fixed_dofs(geometry), symmetry_uy_node_count=geometry.symmetry_node_ids.size)
218: 
219: 
220: def gripper_case(benchmark: Mapping[str, Any], nelx: int, nely: int, *, formulation: str, nu: float,
221:                  thickness_mm: float, symmetry_policy: str) -> MechanismCase:
222:     """The gripper lower half model with an explicit treatment of the soft jaw gap.
223: 
224:     ``symmetry_policy`` is required.  ``"contract_segment"`` applies uy=0 only on the
225:     material part of the symmetry line (x<=60 mm), leaving the ersatz gap free, which
226:     is a slit full model.  ``"full_midline"`` applies uy=0 on every top-row node, which
227:     is the connected mirrored full model.  The jaw face y=30 mm is never constrained.
228:     """
229: 
230:     if symmetry_policy not in SYMMETRY_POLICIES:
231:         raise ValueError(f"symmetry_policy must be one of {SYMMETRY_POLICIES}")
232:     view = runtime_benchmark_v1_1(benchmark)
233:     geometry = build_masks(view, nelx, nely, case="gripper")
234:     fixed = project_fixed_dofs(geometry)
235:     uy_nodes = geometry.symmetry_node_ids.size
236:     if symmetry_policy == "full_midline":
237:         top_row = geometry.nely * (geometry.nelx + 1) + np.arange(geometry.nelx + 1, dtype=np.int64)
238:         fixed = np.unique(np.concatenate((fixed, 2 * top_row + 1)))
239:         uy_nodes = top_row.size
240:     return _build_case(name="gripper", benchmark=benchmark, view=view, geometry=geometry, formulation=formulation,
241:                        nu=nu, thickness_mm=thickness_mm, symmetry_policy=symmetry_policy, fixed_dofs=fixed,
242:                        symmetry_uy_node_count=uy_nodes)
243: 
244: 
245: def reference_stiffness(case: MechanismCase, *, E_scale: float = 1.0, Emin: float = 1.0e-3) -> dict[str, Any]:
246:     """Output-port self-compliance of the all-solid allowed domain without ground springs.
247: 
248:     Solid elements (design and passive solid) carry exactly ``E_scale``; passive void
249:     carries ``Emin``.  ``k_ref = 1 / C_ref`` is the case's own spring scale.  For the
250:     frozen inverter this reproduces the M1 ``C_ref``; it never reads another case's value.
251:     """
252: 
253:     solid = case.design_mask | case.passive_solid_mask
254:     moduli = np.where(solid, float(E_scale), float(Emin)).ravel(order="C")
255:     stiffness = assemble_sparse(moduli, case.unit_ke(), edof_map(case.nelx, case.nely), case.ndof)
256:     free = free_dofs(case.ndof, case.fixed_dofs)
257:     response = factorize(stiffness[free, :][:, free]).solve(case.b_output[free])
258:     compliance = float(case.b_output[free] @ response)
259:     if not np.isfinite(compliance) or compliance <= 0.0:
260:         raise RuntimeError("reference output self-compliance must be finite and positive")
261:     return {
262:         "definition": "inverse_of_output_port_self_compliance_of_the_all_solid_allowed_domain_without_ground_springs",
263:         "C_ref_mm_per_N": compliance,
264:         "k_ref_N_per_mm": 1.0 / compliance,
265:         "case": case.name,
266:         "mesh": [case.nelx, case.nely],
267:         "symmetry_policy": case.symmetry_policy,
268:         "solid_modulus_MPa": float(E_scale),
269:         "void_modulus_MPa": float(Emin),
270:         "material_rule": "design_and_passive_solid_at_E_scale; passive_void_at_Emin",
271:     }
272: 
273: 
274: __all__ = ["CASE_SCHEMA", "MechanismCase", "OUTPUT_SIGN_CONVENTION", "SYMMETRY_POLICIES", "UNITS",
275:            "gripper_case", "inverter_case", "reference_stiffness"]
```

## LF — `src/dmftd/fem/port.py:140–218`

```text
140: def port_vector(
141:     node_ids: ArrayLike,
142:     weights: ArrayLike,
143:     direction: ArrayLike,
144:     ndof: int | None = None,
145: ) -> FloatArray:
146:     """Build the normalized global work-conjugate port vector ``b``.
147: 
148:     ``weights`` must correspond one-for-one with ``node_ids`` and sum to one.
149:     The returned vector uses project DOF ordering
150:     ``[ux_0, uy_0, ux_1, uy_1, ...]``.
151:     """
152: 
153:     nodes = _node_ids(node_ids)
154:     normalized = _normalized_weights(weights, nodes.shape[0])
155:     unit_direction = _unit_direction(direction)
156: 
157:     minimum_ndof = 2 * (int(nodes.max()) + 1)
158:     if ndof is None:
159:         size = minimum_ndof
160:     else:
161:         if isinstance(ndof, bool):
162:             raise TypeError("ndof must be an integer")
163:         try:
164:             size = operator.index(ndof)
165:         except TypeError as exc:
166:             raise TypeError("ndof must be an integer") from exc
167:         if size < minimum_ndof:
168:             raise ValueError("ndof is too small for node_ids")
169:         if size <= 0:
170:             raise ValueError("ndof must be positive")
171: 
172:     vector = np.zeros(size, dtype=np.float64)
173:     vector[2 * nodes] = normalized * unit_direction[0]
174:     vector[2 * nodes + 1] = normalized * unit_direction[1]
175:     return vector
176: 
177: 
178: def port_force(total_force: float, port: ArrayLike) -> FloatArray:
179:     """Distribute a signed total force using a port vector."""
180: 
181:     vector = _global_vector(port, "port")
182:     force = _finite_scalar(total_force, "total_force")
183:     return force * vector
184: 
185: 
186: def port_average_displacement(displacement: ArrayLike, port: ArrayLike) -> float:
187:     """Return the work-conjugate averaged displacement ``b.T @ u``."""
188: 
189:     u = _global_vector(displacement, "displacement")
190:     vector = _global_vector(port, "port")
191:     if u.shape != vector.shape:
192:         raise ValueError("displacement and port must have the same shape")
193:     return float(vector @ u)
194: 
195: 
196: def port_spring_matrix(stiffness: float, port: ArrayLike) -> csc_matrix:
197:     """Return the positive-semidefinite spring matrix ``k * b * b.T``."""
198: 
199:     vector = _global_vector(port, "port")
200:     if not np.any(vector):
201:         raise ValueError("port must not be the zero vector")
202:     spring_stiffness = _finite_scalar(stiffness, "stiffness")
203:     if spring_stiffness < 0.0:
204:         raise ValueError("stiffness must be non-negative")
205:     column = csc_matrix(vector.reshape(-1, 1))
206:     return csc_matrix(spring_stiffness * (column @ column.T))
207: 
208: 
209: def rank_one_port_spring(port: ArrayLike, stiffness: float) -> csc_matrix:
210:     """Descriptive alias for :func:`port_spring_matrix`."""
211: 
212:     return port_spring_matrix(stiffness, port)
213: 
214: 
215: def rank_one_spring(port: ArrayLike, stiffness: float) -> csc_matrix:
216:     """Alias with the concise name used in SG003."""
217: 
218:     return port_spring_matrix(stiffness, port)
```

## LF — `src/dmftd/adjoint.py:113–143`

```text
113:     structural = assemble_sparse(modulus, problem.unit_ke, problem.edof, problem.ndof)
114:     stiffness = csc_matrix(structural + problem.spring_stiffness)
115:     u, free, lu = solve_dirichlet(stiffness, problem.force, problem.fixed)
116:     objective_u = -problem.b_output
117:     adjoint = np.zeros(problem.ndof, dtype=np.float64)
118:     adjoint[free] = lu.solve(objective_u[free], trans="T")
119:     dJ_dE = -np.einsum("ei,ij,ej->e", adjoint[problem.edof], problem.unit_ke, u[problem.edof])
120:     state_residual = float(np.linalg.norm((stiffness @ u - problem.force)[free]) /
121:                            max(float(np.linalg.norm(problem.force[free])), 1.0))
122:     adjoint_residual = float(np.linalg.norm((stiffness.T @ adjoint - objective_u)[free]) /
123:                              max(float(np.linalg.norm(objective_u[free])), 1.0))
124:     q = float(problem.b_output @ u)
125:     return MaterialResult(u=u, adjoint=adjoint, free=free, Kstruct=structural, K=stiffness,
126:                           q=q, J=-q, dJ_dE=dJ_dE, dJ_drho=dJ_dE * derivative,
127:                           state_residual=state_residual, adjoint_residual=adjoint_residual,
128:                           lu_factorizations=1)
129: 
130: 
131: def physical_density_cotangent(
132:     result: MaterialResult, direct_density_gradient: ArrayLike
133: ) -> FloatArray:
134:     """Explicitly add a caller-defined direct term without changing ``result.J``.
135: 
136:     The caller owns the matching augmented scalar (for example the signed
137:     diagnostic ``J_test=J/(1 mm)+0.1*v_design``). This is a covector helper,
138:     not a change to the scientific objective or stored raw sensitivity.
139:     """
140:     direct = _vector(direct_density_gradient, result.dJ_drho.size, "direct_density_gradient")
141:     return result.dJ_drho + direct
142: 
143: 
```

## LF — `src/dmftd/optimization.py:268–365`

```text
268:                      trace_iterations: tuple[int, ...] = TRACE_ITERATIONS,
269:                      initial_design: ArrayLike | None = None) -> OptimizationRun:
270:     """Run one fixed-budget trajectory and reanalyze the returned final design.
271: 
272:     Default M3 execution always takes 200 updates, starting from all design
273:     variables one.  A smaller explicit budget is available for unit tests,
274:     and is returned as ``updates``; it never masquerades as a 200-step run.
275:     ``initial_design`` (E003) replaces the all-ones start with an explicit
276:     compact vector in ``[0, 1]``; convert a full yx array with
277:     ``evaluator.gather``.  The sealed M3 runs used the default.
278:     The callback sees every step's complete trace immediately after updating
279:     and obtaining post-update volumes.  Callback errors propagate unchanged.
280:     """
281:     if isinstance(max_updates, (bool, np.bool_)):
282:         raise ValueError("max_updates must be a positive integer")
283:     updates = operator.index(max_updates)
284:     if updates <= 0:
285:         raise ValueError("max_updates must be a positive integer")
286:     if initial_design is None:
287:         z = np.ones(evaluator.n, dtype=np.float64)
288:     else:
289:         z = _design(initial_design, evaluator.n)
290:     mma = FrozenMMA(z, root=evaluator.root)
291:     initial = evaluator.evaluate(z)
292:     current = initial
293:     history: list[dict[str, Any]] = []
294:     traces: dict[int, dict[str, Any]] = {}
295:     designs = np.empty((updates + 1, *evaluator.shape), dtype=np.float64)
296:     designs[0] = initial.x_yx
297:     selected = set(trace_iterations)
298:     for iteration in range(1, updates + 1):
299:         if iteration > 1:
300:             current = evaluator.evaluate(z)
301:         step = mma.step(current.J_mma, current.dJ_mma, current.constraint, current.dconstraint)
302:         z = step.xmma[:, 0].copy()
303:         x_post = evaluator.scatter(z)
304:         v_post, vt_post = evaluator.volumes(z)
305:         row = {
306:             "iteration": iteration, "state_pre": iteration - 1, "state_post": iteration,
307:             "epoch": step.before.epoch, "epoch_after": step.after.epoch,
308:             "J_pre": current.J, "J_mma_pre": current.J_mma, "q_pre": current.q,
309:             "objective_pre_update": current.J,
310:             "volume_fraction_pre_update": current.v_design,
311:             "volume_fraction_post_update": v_post,
312:             "volume_total_pre_update": current.v_total,
313:             "volume_total_post_update": vt_post,
314:             "constraint_pre_update": float(current.constraint[0, 0]),
315:             "u_in_pre": current.u_in, "v_design_pre": current.v_design,
316:             "v_total_pre": current.v_total, "v_design_post": v_post, "v_total_post": vt_post,
317:             "vf_pre": current.v_design, "vf_post": v_post,
318:             "constraint_pre": float(current.constraint[0, 0]),
319:             "constraint_post": v_post / evaluator.volume_fraction_limit - 1.0,
320:             "x_pre_min": float(np.min(current.z)), "x_pre_max": float(np.max(current.z)),
321:             "x_post_min": float(np.min(z)), "x_post_max": float(np.max(z)),
322:             "state_residual_pre": current.mechanics.state_residual,
323:             "adjoint_residual_pre": current.mechanics.adjoint_residual,
324:             "LU_count_pre": current.mechanics.lu_factorizations,
325:         }
326:         trace = {
327:             "iteration": iteration, "epoch": step.before.epoch, "epoch_after": step.after.epoch,
328:             "x_pre": step.before.xval.copy(), "x_post": step.after.xval.copy(),
329:             "x_yx_pre": current.x_yx.copy(), "x_yx_post": x_post.copy(),
330:             "J_pre": current.J, "J_mma_pre": current.J_mma,
331:             "vf_pre": current.v_design, "vf_post": v_post,
332:             "raw_dJ": current.dJ_raw.copy(), "dJ_to_mma": current.dJ_mma.copy(),
333:             "constraint": current.constraint.copy(), "dconstraint": current.dconstraint.copy(),
334:             "xold1": step.before.xold1.copy(), "xold2": step.before.xold2.copy(),
335:             "low_before": step.before.low.copy(), "upp_before": step.before.upp.copy(),
336:             "low_after": step.after.low.copy(), "upp_after": step.after.upp.copy(),
337:             "xold1_after": step.after.xold1.copy(), "xold2_after": step.after.xold2.copy(),
338:             "xmma": step.xmma.copy(),
339:         }
340:         # The external evidence writer owns persistence and acceptance. Do
341:         # not defer checkpoints until the entire finite trajectory succeeds.
342:         if checkpoint is not None:
343:             checkpoint(iteration, row, trace)
344:         history.append(row)
345:         designs[iteration] = x_post
346:         if iteration in selected:
347:             traces[iteration] = trace
348:     final = evaluator.evaluate(z)
349:     analysis_count = updates + 1
350:     is_project = isinstance(evaluator, ProjectEvaluator)
351:     # Current accepted M2 evaluate_design calls its shared forward chain six
352:     # times: fields, J VJP, volume fields, two volume VJPs, mixed VJP. Each
353:     # post-update volume-only call above adds one forward application.
354:     transforms = 6 * analysis_count + updates if is_project else 0
355:     return OptimizationRun(initial=initial, final=final, history=history, designs=designs,
356:                            traces=traces, optimizer_state=mma.snapshot(),
357:                            analysis_count=analysis_count, volume_field_count=updates if is_project else 0,
358:                            design_transform_application_count=transforms,
359:                            updates=updates, stop_reason="max_iterations")
360: 
361: 
362: __all__ = ["PROJECT_J_SCALE_MM", "PROJECT_PROFILES", "VOLUME_FRACTION_LIMIT", "DEFAULT_MAX_UPDATES",
363:            "TRACE_ITERATIONS", "Evaluation", "AutoEvaluator", "ProjectEvaluator",
364:            "OptimizationRun", "auto_to_yx", "yx_to_auto", "evaluate_auto", "evaluate_project",
365:            "run_optimization"]
```

## LF — `scripts/run_spring_sweep.py:66–119`

```text
66: def run_cell(folder: Path, case, reference: dict, comparison: dict, args, k_hat_in: float, k_hat_out: float) -> dict:
67:     start = time.monotonic()
68:     k_ref = float(reference["k_ref_N_per_mm"])
69:     springs = {"input_spring_N_per_mm": k_hat_in * k_ref, "output_spring_N_per_mm": k_hat_out * k_ref}
70:     material = {"E_scale": E_SCALE_MPA, "Emin": EMIN_MPA, "penal": args.penal}
71:     problem = case.problem(input_force_N=args.input_force_N, **springs)
72:     transform = case.transform(radius_mm=args.filter_radius_mm, beta=args.beta, eta=0.5)
73:     common = dict(profile="project_extension", input_force_N=args.input_force_N,
74:                   volume_fraction_limit=args.volume_fraction, **material)
75:     probe = ProjectEvaluator(problem, transform, J_scale=1.0, **common)
76:     z0 = probe.gather(initial_field(args.initial, case, args.volume_fraction))
77:     initial = probe.evaluate(z0)
78:     if args.j_scale_rule == "abs_J_initial_v1":
79:         j_scale = abs(initial.J)
80:         if not j_scale >= 1.0e-9:
81:             raise RuntimeError(f"J_SCALE_DEGENERATE: |J(z0)| = {j_scale:.3e} mm")
82:     else:
83:         j_scale = float(args.j_scale)
84:     evaluator = ProjectEvaluator(problem, transform, J_scale=j_scale, **common)
85:     run = run_optimization(evaluator, max_updates=args.updates, initial_design=z0)
86:     final = run.final
87:     rho = final.fields.rho_physical
88:     measured = measure_case(rho, case, comparison, direct_checks=True)
89:     ports = two_port_compliance(case, rho, penal=args.penal, input_force_N=args.input_force_N, **springs)
90:     j_pre = [row["objective_pre_update"] for row in run.history]
91:     tail = min(TAIL, len(j_pre) - 1)
92:     tail_change = abs(j_pre[-1] - j_pre[-1 - tail]) / max(abs(j_pre[-1]), 1e-12) if tail > 0 else None
93:     design_change = float(np.max(np.abs(run.designs[-1] - run.designs[-1 - tail]))) if tail > 0 else None
94:     excess = max(final.v_design - args.volume_fraction, 0.0)
95:     scalars = {role: {"J_mm": value.J, "q_mm": value.q, "q_in_mm": value.u_in, "v_design": value.v_design,
96:                       "v_total": value.v_total}
97:                for role, value in (("initial", run.initial), ("final", final))}
98:     summary = {
99:         "schema": "dmftd.spring_sweep_cell.v1", "status": "ok", "case": case.name,
100:         "symmetry_policy": case.symmetry_policy, "mesh": [case.nelx, case.nely],
101:         "source_profile": {
102:             "k_hat_in": k_hat_in, "k_hat_out": k_hat_out, **springs, "k_ref_N_per_mm": k_ref,
103:             "k_ref_source": reference["source"], "input_force_N": args.input_force_N,
104:             "volume_fraction_limit": args.volume_fraction, "volume_fraction_denominator": "design_domain_elements",
105:             "filter_radius_mm": args.filter_radius_mm, "beta": args.beta, "eta": 0.5, "penal": args.penal,
106:             "Emin_MPa": EMIN_MPA, "E_scale_MPa": E_SCALE_MPA, "initial_design": args.initial,
107:             "updates": args.updates, "J_scale_rule": args.j_scale_rule, "J_scale_mm": j_scale,
108:             "stop_reason": run.stop_reason, "converged": False, "profile": evaluator.profile,
109:         },
110:         "source_result": {
111:             **scalars, "J_mma_initial": run.initial.J_mma,
112:             "input_spring_force_N": springs["input_spring_N_per_mm"] * final.u_in,
113:             "output_spring_force_N": springs["output_spring_N_per_mm"] * final.q,
114:             "feasible": bool(excess <= 1e-6), "constraint_excess": excess,
115:             "output_sign": "positive_along_output_direction" if final.q > 0 else "reversed_or_zero",
116:             "tail_updates": tail, "tail_relative_J_change": tail_change, "tail_max_design_change": design_change,
117:             "state_residual": final.mechanics.state_residual, "adjoint_residual": final.mechanics.adjoint_residual,
118:             "history_compact": {
119:                 "iteration": [row["iteration"] for row in run.history], "J_pre_mm": j_pre,
```

## LF — `scripts/run_n4_pilot_gripper.py:139–172`

```text
139:                                                 "q_in_formula_vs_run_relative": abs(ports["q_in_formula_mm"] - final.u_in) / max(abs(final.u_in), 1e-12)},
140:         "comparison_profile": comparison,
141:         "comparison_result": {"all_hard_checks_pass": measured["all_hard_checks_pass"], "metrics": measured["metrics"], "curves": measured["curves"],
142:                               "block": measured["block"], "checks": measured["checks"]},
143:         "elapsed_seconds": time.monotonic() - start,
144:     }
145:     folder.mkdir(parents=True, exist_ok=True)
146:     write_json(folder / "summary.json", summary)
147:     write_json(folder / "history.json", {"rows": run.history})
148:     np.savez_compressed(folder / "arrays.npz", rho_physical_final=rho, raw_design_final=final.x_yx, u_source_final=final.mechanics.u,
149:                         measurement_u_free=measured["arrays"]["u_free"], measurement_w=measured["arrays"]["w"])
150:     return summary
151: 
152: 
153: def qualify(rho: np.ndarray, case) -> tuple[np.ndarray, np.ndarray, dict]:
154:     """Frozen strict rule on the final binary geometry (threshold 0.5, load-path clean-up): volume, connectivity, hinges, ports, supports."""
155: 
156:     binary = binarize(rho, case, threshold=SETTINGS["binarisation_threshold"])
157:     path8 = load_path(binary, case, connectivity=8)
158:     clean = path8["clean"] if path8["connected"] else binary
159:     diag = v1x.diagnostics(clean, case)
160:     n_domain = int(case.design_mask.sum())
161:     solid_in_domain = int(clean[case.design_mask].sum())
162:     volume_ok = solid_in_domain * 100 <= STRICT_LIMIT_PERCENT * n_domain
163:     ports_ok = bool(all(diag["ports_attached_to_solid"].values()))
164:     criteria = {"binary_volume_le_0.35": volume_ok, "load_path_8_connected": bool(diag["connected_8"]), "load_path_4_connected": diag["connected_4"] is True,
165:                 "no_corner_only_hinges": diag["corner_only_hinges"] is False, "support_restrained": bool(diag["restrained"]), "ports_attached": ports_ok}
166:     strict = all(criteria.values())
167:     return clean, binary, {"rule": "binary volume fraction on the native design domain <= 0.35 (exact integer comparison) and 8- and 4-connected load path (support, input, output) "
168:                                    "and no corner-only hinges and support restrained and both ports attached; 1-element thin necks are a label, not a criterion",
169:                            "binary_volume_fraction": solid_in_domain / n_domain, "solid_elements_in_design_domain": solid_in_domain, "design_domain_elements": n_domain,
170:                            "island_elements_removed": int(path8["island_elements"]) if path8["connected"] else None, "clean_mask_is_binarised_mask": not path8["connected"],
171:                            **{k: v for k, v in diag.items() if k not in ("solid_elements", "design_volume_fraction_binary")},
172:                            "criteria": criteria, "failed_criteria": [k for k, v in criteria.items() if not v], "strict_qualified": bool(strict),
```

## LF — `scripts/export_hf_designs_v2.py:120–190`

```text
120:     """Write ``folder/design.json`` + ``design.npz`` in schema v2 and return the index entry.
121: 
122:     ``scoring_reference`` / ``scoring_profile`` (exporter revision 2.2, erratum N4-P3-C1): the reference and the common comparison
123:     profile under which the floor-free LF score ``ersatz_floor_free.native.comparison_profile.q_free_mm`` is measured.  A caller
124:     whose experiment pins k_ref (the N4 pilot and formal pools) MUST pass them: without them the exporter measures under the
125:     native mesh's own reference, which is what happened to the 1800 formal packages (k_in 1.4339777... instead of the frozen
126:     1.4604287... N/mm).  The default stays the native own reference for the historical handoff re-export, whose definition it is.
127:     """
128: 
129:     if (scoring_reference is None) != (scoring_profile is None):
130:         raise ValueError("scoring_reference and scoring_profile are passed together")
131:     cache = {} if cache is None else cache
132:     clock = time.monotonic()
133:     solid = np.asarray(solid, dtype=bool)
134:     ny, nx = solid.shape
135:     case_native, ref_native, cmp_native = get_case(cache, kind, nx, ny, symmetry_policy)
136:     case_fine, _, _ = get_case(cache, kind, int(analysis_mesh[0]), int(analysis_mesh[1]), symmetry_policy)
137:     solid_fine = v1.nested(solid, int(analysis_mesh[0]), int(analysis_mesh[1]))
138:     gid = v1.geometry_id(kind, solid, case_native.passive_solid_mask, case_native.passive_void_mask, case_native.thickness_mm)
139:     folder.mkdir(parents=True, exist_ok=False)
140:     npz_path = folder / "design.npz"
141:     np.savez_compressed(npz_path, solid=solid, passive_solid=case_native.passive_solid_mask, passive_void=case_native.passive_void_mask, design_domain=case_native.design_mask)
142:     record = {
143:         "schema": SCHEMA_V2, "design_id": design_id, "case": kind, "geometry_id": gid,
144:         "geometry_id_rule": "content hash of (case, native mesh, domain, thickness, solid, passive_solid, passive_void) with the v1 header: identical for the same geometry in v1 and v2",
145:         "grid": {"native_mesh": [nx, ny], "domain_mm": list(v1.DOMAIN_MM), "cell_mm": [case_native.hx_mm, case_native.hy_mm], "origin_mm": [0.0, 0.0],
146:                  "axes": "+x right, +y up; array index [j, i] = [row from bottom, column from left]", "model_extent": "lower half model; mirror plane y = 40 mm",
147:                  "thickness_mm": case_native.thickness_mm, "analysis_mesh": [int(analysis_mesh[0]), int(analysis_mesh[1])], "analysis_rule": "integer nested copy of native cells"},
148:         "arrays": {"file": "design.npz", "keys": {"solid": "bool ny x nx, 1 = mechanism solid", "passive_solid": "forced solid", "passive_void": "forced void",
149:                                                   "design_domain": "cells the LF optimizer controlled"}, "sha256": v1.sha256_file(npz_path)},
150:         "regions_mm": regions_v2(case_native, kind),
151:         "diagnostics": {"native": {**v1.diagnostics(solid, case_native), "support_attachment": support_attachment(solid, case_native, kind)},
152:                         "analysis": {**v1.diagnostics(solid_fine, case_fine), "support_attachment": support_attachment(solid_fine, case_fine, kind)}},
153:         "exporter": {"revision": "2.2", "history": {"2.0": "2026-09-18 v2 schema (E006-D1): research/hf_export_v2 and the N4-P2 pilot packages",
154:                                                      "2.1": "2026-09-18 diagnostics gain support_attachment (label only; schema unchanged)",
155:                                                      "2.2": "2026-09-19 erratum N4-P3-C1: the scoring reference / comparison profile can be passed explicitly and is recorded and checked"}},
156:         "scoring_profile": {"source": "explicit: the caller's frozen scoring reference and comparison profile" if scoring_profile is not None
157:                                       else "native own reference of the package mesh (historical handoff definition)",
158:                             "k_in_N_per_mm": float((scoring_profile or cmp_native)["input_spring_N_per_mm"]), "k_ref_N_per_mm": float((scoring_reference or ref_native)["k_ref_N_per_mm"]),
159:                             "native_own_k_ref_N_per_mm": float(ref_native.get("own_mesh_k_ref_N_per_mm", ref_native["k_ref_N_per_mm"]))},
160:         "lf_reference": references(solid, solid_fine, case_native, case_fine, kind, scoring_reference or ref_native, scoring_profile or cmp_native, E=E_SCALE_MPA, nu=nu),
161:         "source": source, **(extra or {}), "elapsed_seconds": time.monotonic() - clock,
162:     }
163:     measured = record["lf_reference"].get("ersatz_floor_free", {})
164:     if isinstance(measured.get("native"), dict) and measured["native"]["comparison_profile"]["k_in_N_per_mm"] != record["scoring_profile"]["k_in_N_per_mm"]:
165:         raise RuntimeError("the floor-free LF score was not measured under the declared scoring profile")  # the measured input spring must BE the declared one
166:     write_json(folder / "design.json", record)
167:     exact = record["lf_reference"]["exact_active_solid"]
168:     native_exact = exact.get("native", {}) if isinstance(exact, dict) else {}
169:     return {"design_id": design_id, "case": kind, "geometry_id": gid, "native_mesh": [nx, ny], "design_json_sha256": v1.sha256_file(folder / "design.json"),
170:             "design_npz_sha256": record["arrays"]["sha256"],
171:             "exact_active_solid_native": {k: native_exact.get(k) for k in ("gain_qout_over_qin", "input_stiffness_N_per_mm", "status")},
172:             "connected_4_native": record["diagnostics"]["native"]["connected_4"], "thin_necks_native": record["diagnostics"]["native"]["thin_necks_1_element"],
173:             "strict_qualified": (extra or {}).get("qualification", {}).get("strict_qualified")}
174: 
175: 
176: def main() -> int:
177:     parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
178:     parser.add_argument("--output", type=Path, required=True)
179:     parser.add_argument("--handoff", type=Path, default=ROOT / "research/handoff_v2/handoff_v2.json")
180:     parser.add_argument("--policy", type=Path, default=ROOT / "research/l3_interval_policy_v1/policy.json")
181:     parser.add_argument("--analysis-mesh", type=int, nargs=2, default=[160, 80], metavar=("NX", "NY"))
182:     parser.add_argument("--nu", type=float, default=0.3)
183:     parser.add_argument("--only", nargs="*", default=None)
184:     args = parser.parse_args()
185:     started = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
186:     output = args.output.resolve()
187:     if output.exists():
188:         raise SystemExit(f"refusing to overwrite an existing directory: {output}")
189:     output.mkdir(parents=True)
190:     handoff = json.loads(args.handoff.read_text(encoding="utf-8"))
```

## LF — `research/n4_formal_gripper_v1/README.md:1–45`

```text
1: # N4-P3：正式独立池的 LF-only 生成（夹持器，200 池 × 9 格 = 1 800 次，2026-09-18／19）
2: 
3: N 线（`Compliant-Nonlinear-TMC-A`）N4 公平多样性实验的正式候选生成。协议 `N4_P3_protocol_v1.md`（本目录为 N 仓库 `docs/N4_P3_protocol_v1.md` 在 N 提交 `902332a` 的逐字节副本，所有者 2026-09-18 确认并冻结）。**本目录只有 LF 侧信息：没有任何 HF 评价。** 选择顺序、HF 标签库与统计在 N 仓库 `research/n4_p3_formal_v1/`。
4: 
5: ## 冻结与绑定
6: 
7: `protocol_freeze.json` 绑定：协议文本的换行规范化 SHA-256 `7150dc09c6a49df0a8b654be271b67b56f7c9e3dea858bff29635ffac21e9648`、200 池／1 800 行、计算前运行清单 `run_list.json` 的逐字节 SHA-256 `c5685f827a10925713da927d66aff8fb7c8a8aedde9f0c931188379a499c3f30`、完整数值运行规格的 SHA-256 `6de7d2bbe48cead84270774c6421f9b1cf544ee3e15bddccafdbf6b6714556ba`。运行器 `scripts/run_n4_formal_gripper.py` 在每次真实调用时重新计算并核对，不符即拒绝；`--only` 只能选取清单成员；已终止失败不自动重试（显式 `--rerun-failed` + 理由，保留全部尝试与成本）；纯控制流测试 `tests/test_n4_formal_runner.py`（10 项）。
8: 
9: ## 设计（与 N4-P2 试点相同的生成、资格与导出函数，未改动）
10: 
11: 池 i 的种子 = 20260920 + i（i = 0 … 199，试点种子已排除）；每池一个随机初始场 x₀ = clip(0.340 + 0.15·U(−1, 1), 0, 1)（九格共用同一噪声数组）；弹簧格 k̂_in ∈ {0.1, 1, 10} × k̂_out ∈ {1, 10^0.5, 10}，k_ref = 1.4604287860303493 N/mm（钉定）；夹持器 `full_midline`、160×80、v_LF = 0.340、p = 3、β = 4、η = 0.5、滤波 3 mm、200 次 MMA 更新。严格资格：二值体积 ≤ 0.35（整数比较）、8／4 邻接承载路径、无仅角点铰接、支座受约束、端口附着；细颈与支承附着长度只作标签。
12: 
13: ## 执行
14: 
15: 本机 WSL2、仓库 `.venv`（CPython 3.11.13 / NumPy 1.26.4 / SciPy 1.12.0 / JAX 0.4.30，`JAX_ENABLE_X64=True`，每进程 `OPENBLAS_NUM_THREADS=1`），18 个 worker，单次调用、无中断、无复跑；生成提交 `0e917ad`；墙钟 46 836 s（13.0 h）；各作业经过时间之和 231.0 h（单作业 340–570 s，含并行争用，不是 CPU 计时）。
16: 
17: ## 结果（LF-only；细节见 `summary.md`、`index.json`）
18: 
19: | 量 | 值 |
20: | --- | --- |
21: | 预定／成功／终止失败／未运行 | 1 800／1 800／0／0（每次运行 1 次尝试，无复跑、无复用） |
22: | 严格合格 | 1 800／1 800；二值体积 0.3418–0.3468（中位 0.3435），全部低于 0.35 |
23: | 每池唯一合格 P | 200 个池全部为 9；完全重复 0（1 800 个几何两两不同）；细颈标签 0 |
24: | 每池 C(η = 0.5) | 7：195 个池；8：5 个池；C 小于主预算 3 的池：0 |
25: | 池内 XOR 最小值 | 0.0076–0.0415（中位 0.0124）：每池都有近重复对 |
26: | 支承附着长度 | k̂_in = 0.1 → 0.5 mm（600）；k̂_in = 1 → 1.5 mm（599）、2.0 mm（1）；k̂_in = 10 → 2.0 mm（600） |
27: 
28: ## 勘误 C1（2026-09-19）：LF 分数的测量口径
29: 
30: 本目录 1 800 个包的 `lf_reference.ersatz_floor_free.native.comparison_profile` 是在 **k_in = 1.4339777207450293 N/mm**（原生 160×80 网格自身的 k_ref）下测得的；冻结协议与 `run_list.json`／`index.json` 的 `comparison_profile` 规定的是钉定值 **1.4604287860303493 N/mm**。原因：运行器没有把评分 reference／profile 传给导出器，导出器按原生网格重建了它们。生成弹簧、几何、资格不受影响。**包不重写**（它们的哈希已被 N 侧 HF 标签记录绑定）；逐设计的勘误层 `score_erratum_c1.json` 给出实际与恢复后的分数：L(k) = q_out(0)／(1 + k·C_in(0))（秩一输入弹簧的 Sherman–Morrison 恒等式），重建实际分数的最大相对误差 1.51e-12，12 个设计在钉定 profile 下的直接线性测量与恒等式相差 ≤ 6.2e-13；恢复／实际 = 0.982226–0.984491。对 N 侧选择的影响与两版对照见 N 仓库 `research/n4_p3_formal_v1/erratum_c1/`。修复：导出器修订 2.2 显式接收并核对评分 profile，两个运行器传入钉定 reference（`tests/test_n4_scoring_profile.py`）；同时修了失败尝试耗时漏计的问题（本批无失败，成本数字不变）。
31: 
32: 状态（2026-09-19，第十二轮有限复审，N 仓库 `research/n4_p3_c1_review_external/`）：勘误 C1 通过并关闭，N4-P3 以"正式计算完成，附 C1 评分口径偏差及勘误"关闭；本目录的包、索引、清单、冻结记录与勘误层都不需要改动。之后的 N4-P4a（N 仓库 `docs/N4_P4a_diagnosis_and_pilot_proposal.md`）是只读已有数据的离线诊断：它读取本目录的 `export_v2/<id>/design.json`（k_in = 0 去地板端口量）与 `score_erratum_c1.json`，不运行任何 LF 优化；新的候选生成须另经所有者授权。
33: 
34: ## 目录
35: 
36: | 文件 | 内容 |
37: | --- | --- |
38: | `N4_P3_protocol_v1.md`、`protocol_freeze.json` | 冻结协议的副本与绑定记录 |
39: | `run_list.json` | 计算前写盘的 1 800 行清单（未改动） |
40: | `index.json`、`summary.md` | 1 800 行逐运行记录（状态、资格、二值体积、去地板 q_free、标签、掩膜哈希、geometry_id、尝试与成本、代码提交）与分池分析（尝试、唯一 P、完全重复、C(η = 0.5)／C(η = 0)、XOR、成本账） |
41: | `export_v2/<id>/` | 1 800 个 `dmftd.hf_export.v2` 自包含包（导出器修订 2.1；权威的最终几何；含 `generation`、`qualification`、`lf_reference`、`support_attachment`） |
42: | `score_erratum_c1.json` | 勘误 C1 的逐设计评分勘误层（写于 HF 标签解盲之后；包、索引、清单、冻结记录均未改动） |
43: | `archive_manifest.json` | 仓库外科学归档 `n4_p3_lf_pools/v1` 的索引（12 600 个文件、约 1.9 GB：每次运行的 `arrays.npz`、完整 `history.json`、`summary.json`、`geometry.npz`、`row.json`、`spec.json`、`attempts.jsonl`）；两份副本逐文件核验；`python scripts/archive_run_tree.py --verify <归档根>/n4_p3_lf_pools/v1 --manifest research/n4_formal_gripper_v1/archive_manifest.json` |
44: 
45: 原始运行不进入 Git（所有者决定：不用 LFS、不重写历史）；运行的身份 = 相对归档路径 + 哈希。归档于 2026-09-19 完成：两份副本各 12 600 个文件、1 880.9 MB，逐文件核验通过（无缺失、无不一致、无未索引）；恢复测试：从第二副本随机读回 40 个运行，`geometry.npz` 的清理掩膜哈希 = 索引行 = 归档行，清理掩膜 = v2 包实体掩膜，且落在归档密度的 0.5 阈值之内（40／40）。
```

## HF — `hf_repo/src/hf_eval/data.py:1–43`

```text
1: """Portable binary-cell geometry records, independent of any geometry producer."""
2: 
3: from __future__ import annotations
4: 
5: from copy import deepcopy
6: from dataclasses import dataclass
7: from hashlib import sha256
8: from io import BytesIO
9: import json
10: from pathlib import Path
11: from typing import Any
12: from zipfile import BadZipFile
13: 
14: import numpy as np
15: 
16: 
17: ARRAY_NAMES = ("solid", "design", "passive_solid", "passive_void")
18: SCHEMA_VERSION = "hf-geometry-1.0"
19: 
20: 
21: class GeometryError(ValueError):
22:     """A geometry record is invalid, unsupported, or fails integrity checks."""
23: 
24: 
25: @dataclass(frozen=True)
26: class Geometry:
27:     metadata: dict
28:     arrays: dict[str, np.ndarray]
29:     path: Path
30: 
31:     @property
32:     def solid(self) -> np.ndarray:
33:         return self.arrays["solid"]
34: 
35:     @property
36:     def grid(self) -> dict:
37:         return self.metadata["grid"]
38: 
39:     @property
40:     def geometry_id(self) -> str:
41:         return self.metadata["geometry_id"]
42: 
43: 
```

## HF — `hf_repo/src/hf_eval/data.py:270–337`

```text
270:         raise GeometryError("Writer does not overwrite symbolic links")
271:     array_path.write_bytes(payload)
272:     descriptor_path.write_text(serialized, encoding="utf-8")
273:     return descriptor_path.resolve()
274: 
275: 
276: def _json_object(pairs: list[tuple]) -> dict:
277:     result = {}
278:     for key, value in pairs:
279:         if key in result:
280:             raise GeometryError(f"Duplicate JSON key: {key}")
281:         result[key] = value
282:     return result
283: 
284: 
285: def _array_path(descriptor: Path, value: Any) -> Path:
286:     # V1 deliberately permits only a file name next to geometry.json.
287:     if not isinstance(value, str) or value in ("", ".", "..") or any(c in value for c in "/\\:"):
288:         raise GeometryError("arrays.path must be a same-directory relative file name")
289:     result = descriptor.parent / value
290:     if result.resolve().parent != descriptor.parent.resolve():
291:         raise GeometryError("Array path resolves outside the geometry package")
292:     return result
293: 
294: 
295: def load_geometry(path: str | Path) -> Geometry:
296:     descriptor = Path(path)
297:     if descriptor.is_dir():
298:         descriptor = descriptor / "geometry.json"
299:     if descriptor.is_symlink():
300:         raise GeometryError("Geometry descriptor must be a regular local file, not a symbolic link")
301:     descriptor = descriptor.resolve()
302:     try:
303:         metadata = json.loads(descriptor.read_text(encoding="utf-8"), object_pairs_hook=_json_object)
304:         if not isinstance(metadata, dict):
305:             raise GeometryError("Geometry descriptor must be an object")
306:         supplied_descriptor_hash = metadata.get("descriptor_sha256")
307:         unsigned = {key: value for key, value in metadata.items() if key != "descriptor_sha256"}
308:         if supplied_descriptor_hash != canonical_hash(unsigned):
309:             raise GeometryError("descriptor_sha256 mismatch")
310:         normalized = _normalize_metadata(metadata)
311:         definition = normalized.get("arrays")
312:         if not isinstance(definition, dict) or not isinstance(definition.get("fields"), dict):
313:             raise GeometryError("arrays must declare path, sha256, and fields")
314:         array_path = _array_path(descriptor, definition.get("path"))
315:         payload = array_path.read_bytes()
316:         if sha256(payload).hexdigest() != definition.get("sha256"):
317:             raise GeometryError("NPZ file sha256 mismatch")
318:         with np.load(BytesIO(payload), allow_pickle=False) as archive:
319:             if set(archive.files) != set(ARRAY_NAMES) or len(archive.files) != len(ARRAY_NAMES):
320:                 raise GeometryError("NPZ field names do not match the four authority arrays")
321:             arrays = _validated_arrays(
322:                 {name: archive[name] for name in ARRAY_NAMES}, normalized["grid"]["shape_yx"], require_uint8=True,
323:             )
324:         if set(definition["fields"]) != set(ARRAY_NAMES):
325:             raise GeometryError("Array field declarations do not match authority arrays")
326:         for name in ARRAY_NAMES:
327:             if definition["fields"][name] != _field_info(arrays[name]):
328:                 raise GeometryError(f"Array {name} content hash or declaration mismatch")
329:         if normalized.get("geometry_id") != _geometry_hash(normalized, arrays):
330:             raise GeometryError("geometry_id mismatch")
331:     except GeometryError:
332:         raise
333:     except (OSError, ValueError, TypeError, KeyError, EOFError, BadZipFile) as error:
334:         raise GeometryError(f"Cannot read geometry {descriptor}: {error}") from error
335:     for array in arrays.values():
336:         array.setflags(write=False)
337:     return Geometry(normalized, arrays, descriptor)
```

## HF — `lf_data_preparation/export_snapshot.py:1–24`

```text
1: """One-time, data-only export of the explicitly authorized LF snapshot subset.
2: 
3: This script belongs outside the HF runtime. It never imports LF packages.
4: """
5: from __future__ import annotations
6: import argparse
7: import collections
8: import hashlib
9: import io
10: import json
11: from pathlib import Path, PurePosixPath
12: import platform
13: import sys
14: import zipfile
15: 
16: import numpy as np
17: from hf_eval.data import write_geometry
18: 
19: SELECTED = {
20:     'inverter': 'inverter__sweep__kin_1e+01__kout_1e-01',
21:     'gripper': 'gripper__sweep__kin_1e+01__kout_1e+00',
22: }
23: ARRAYS = ('solid', 'design', 'passive_solid', 'passive_void')
24: 
```

## HF — `lf_data_preparation/export_snapshot.py:165–208`

```text
165:         'thickness_mm':cr['thickness_mm'],'model_extent':{'kind':'lower_half','symmetry_axis':{'normal':[0,1],'offset_mm':40.}},
166:         'region_tags':{'support':{'points_mm':cr['fixed_segment_mm'],'components':[0,1]},
167:                        'symmetry':{'points_mm':[[0,40],[60 if case=='gripper' else 80,40]],'components':[1]},**ports},
168:         'source_record_ids':[ident],
169:         'processing':{'source_kind':'archived_LF_optimization_budget_terminal','authority_source_key':'clean',
170:             'source_native_grid_preserved':True,'lossless_bool_to_uint8':True,'new_threshold_or_cleanup_applied':False,
171:             'original_threshold':summary['diagnostics']['threshold'],
172:             'historical_cleaning':'eight-neighbor load-path selection; opened arrays diagnostic only',
173:             'historical_removed_island_cells':int((original['solid']&~clean).sum()),
174:             'source_symmetry_policy':cr['symmetry_policy'],
175:             'source_symmetry_points_mm':[[0,40],[80,40]],
176:             'imported_entity_symmetry_points_mm':[[0,40],[60 if case=='gripper' else 80,40]],
177:             'source_symmetry_note':'full_midline includes LF soft gap; gripper canonical tag retains entity symmetry segment x0..60 only; source void constraints are not copied',
178:             'provenance_record':'provenance/source_record.json','role':'diagnostic_HF1_candidate_qualification_pending'}}
179:     directory=out/'canonical'/case
180:     geometry_path=write_geometry(directory,metadata,arrays)
181:     provenance=directory/'provenance';provenance.mkdir(parents=True,exist_ok=True)
182:     for source,target in [(base+'/geometry.npz','original_geometry.npz'),(base+'/outline.json','outline.json'),
183:                           (base+'/summary.json','geometry_extraction_summary.json'),(run_summary_path,'source_run_summary.json')]:
184:         (provenance/target).write_bytes(s.bytes(source))
185:     np.savez_compressed(provenance/'continuous_source.npz',rho_physical=density,
186:         raw_design=density_container['raw_design_final'][tuple(ds['index'])],
187:         design_mask=arrays['design'],passive_solid_mask=arrays['passive_solid'],passive_void_mask=arrays['passive_void'])
188:     write_json(provenance/'source_case_profile.json',{'case_record':cr,'source_profile_common':index['source_profile_common'],
189:         'reference':index['reference'],'source_provenance':index['provenance'],
190:         'geometry_extraction_provenance':s.json('research/geometry_extraction_v1/index.json')['provenance'],
191:         'handoff_v2_provenance':s.json('research/handoff_v2/handoff_v2.json')['provenance']})
192:     assets=[]
193:     for p in sorted(provenance.iterdir()):
194:         if p.is_file() and p.name!='source_record.json':assets.append({'path':p.name,'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size})
195:     write_json(provenance/'source_record.json',{'schema_version':'hf-generation-1.0','record_id':ident,
196:         'source_archive_sha256':archive_hash,'source_archive_basename':s.path.name,
197:         'original_geometry_member':s.prefix+base+'/geometry.npz','original_geometry_sha256':digest(s.bytes(base+'/geometry.npz')),
198:         'original_density_member':s.prefix+ds['file'],'original_density_sha256':digest(s.bytes(ds['file'])),
199:         'original_density_key':ds['key'],'original_density_index':ds['index'],
200:         'continuous_density_role':'provenance_only_not_authoritative_geometry','assets':assets,
201:         'optimization_status':{'stop_reason':run['source_profile']['stop_reason'],'converged':run['source_profile']['converged'],
202:             'updates':run['source_profile']['updates'],'initial_design':run['source_profile']['initial_design'],'random_seed':None,
203:             'seed_reason':'selected uniform initial field does not use RNG'},
204:         'source_metrics':run['source_result']['final'],'source_lf_profile':run['source_profile'],
205:         'source_cost_seconds':record['source_cost_seconds'],'source_cost_scope':record['source_cost_scope'],
206:         'new_optimization_in_HF1':False,'paths_and_commands_in_source_documents':'inert_history_only'})
207:     saved=json.loads(Path(geometry_path).read_text())
208:     return {'case_family':case,'source_record_id':ident,'geometry_id':saved['geometry_id'],
```

## HF — `hf_repo/src/hf_eval/project.py:90–175`

```text
90: def _validate_task(task_dict):
91:     required = {
92:         "schema_version", "task_id", "case_family", "units", "material",
93:         "third_medium", "regularization", "input", "output", "constraints",
94:         "support_selection", "background_symmetry", "input_auxiliary_spring_N_per_mm",
95:         "workpiece", "reference_state", "qualification_criteria",
96:     }
97:     _object(task_dict, "task", required,
98:             {"diagnostic_variant", "purpose", "parameter_origin", "description"})
99:     task = deepcopy(task_dict)
100:     _require(task["schema_version"] == TASK_SCHEMA, f"Expected {TASK_SCHEMA}")
101:     _require(isinstance(task["task_id"], str) and bool(task["task_id"].strip()), "task_id must be nonempty")
102:     _require(isinstance(task["case_family"], str) and task["case_family"] in {"inverter", "gripper"},
103:              "Only the two HF-3 project families are supported")
104:     _require(task["units"] == UNITS, "Project units must be mm, N, MPa and N mm")
105:     material = _object(task["material"], "material", {"E_MPa", "nu", "formulation"})
106:     _require(material["formulation"] == "plane_strain", "Only plane strain is supported")
107:     E = _number(material["E_MPa"], "E_MPa", positive=True)
108:     nu = _number(material["nu"], "nu")
109:     _require(E == 1.0 and nu == 0.3, "HF-3 pilot material is frozen at E=1 MPa and nu=0.3")
110:     medium = _object(task["third_medium"], "third_medium", {"gamma"})
111:     gamma = _number(medium["gamma"], "third_medium.gamma", positive=True)
112:     _require(gamma == 1e-6, "HF-3 third-medium factor is frozen at 1e-6")
113:     regularization = _object(task["regularization"], "regularization", {"alpha", "length_mm"})
114:     alpha = _number(regularization["alpha"], "regularization.alpha", positive=True)
115:     length = _number(regularization["length_mm"], "regularization.length_mm", positive=True)
116:     _require(alpha == 1e-6 and length == 80.0, "HF-3 regularization uses alpha=1e-6 and Lr=80 mm")
117:     inlet = _object(task["input"], "input", {"tag", "control", "target_mm"})
118:     _require(inlet["tag"] == "input" and inlet["control"] == "average_displacement",
119:              "Input must use the reference input tag and average displacement control")
120:     _number(inlet["target_mm"], "input.target_mm", positive=True)
121:     outlet = _object(task["output"], "output", {"tag", "spring_N_per_mm"})
122:     _require(outlet["tag"] == "output", "Output must use the reference output tag")
123:     kout = _number(outlet["spring_N_per_mm"], "output.spring_N_per_mm")
124:     auxiliary = _number(task["input_auxiliary_spring_N_per_mm"], "input_auxiliary_spring_N_per_mm")
125:     _require(kout == auxiliary == 0.0, "The project pilot has free output and no input auxiliary spring")
126:     _require(task["workpiece"] is None and task["reference_state"] == "undeformed",
127:              "HF-3 has no workpiece and starts from the undeformed state")
128:     _require(task["support_selection"] == "solid_incident_nodes_only",
129:              "Solid constraints must select solid-incident nodes only")
130:     constraints = task["constraints"]
131:     _require(isinstance(constraints, list) and len(constraints) == 2, "Declare support and symmetry constraints separately")
132:     declared = {}
133:     for constraint in constraints:
134:         _object(constraint, "constraint", {"tag", "components"})
135:         tag = constraint["tag"]
136:         _require(isinstance(tag, str) and tag not in declared, "Constraint tags must be distinct strings")
137:         components = constraint["components"]
138:         _require(isinstance(components, list) and all(type(c) is int for c in components),
139:                  "Constraint components must be integer lists")
140:         declared[tag] = components
141:     _require(declared == {"support": [0, 1], "symmetry": [1]}, "Unsupported solid constraint components or tags")
142:     background = _object(task["background_symmetry"], "background_symmetry", {"points_mm", "components"})
143:     _require(background["points_mm"] == [[0.0, 40.0], [80.0, 40.0]]
144:              and background["components"] == [1]
145:              and all(type(c) is int for c in background["components"]),
146:              "Declare the complete y=40 mm background uy symmetry line explicitly")
147:     variant = task.get("diagnostic_variant", "none")
148:     _require(isinstance(variant, str) and variant in {"none", BACKGROUND_DIAGNOSTIC}, "Unsupported boundary diagnostic variant")
149:     _require(variant == "none" or task["case_family"] == "gripper", "The background-release diagnostic is only defined for the gripper")
150:     criteria = _object(task["qualification_criteria"], "qualification_criteria",
151:                        {"max_design_volume_fraction", "min_feature_mm"})
152:     _require(all(value is None for value in criteria.values()), "Research qualification thresholds remain pending in this pilot")
153:     canonical_hash(task)  # Reject non-JSON/nonfinite inert metadata as well.
154:     return task, E, nu, gamma, alpha, length, kout, variant
155: 
156: 
157: def build_project(geometry_file: str | Path, task_dict: dict) -> Project:
158:     """Map one portable geometry and explicit HF-3 task to a full-domain model.
159: 
160:     ``task_hash`` is ``data.canonical_hash`` of the validated, copied task as
161:     supplied. ``region_metadata`` is ordinary JSON, including the separate DOF
162:     sets, their intersections and the merged fixed DOFs. Forces and energy refer
163:     to the modeled lower half, without automatic doubling. No loads are solved.
164:     The one gripper boundary variant is marked for initial-tangent diagnosis;
165:     the runner must not use it for a complete nonlinear pilot path.
166:     """
167:     task, E, nu, medium, alpha, length, kout, variant = _validate_task(task_dict)
168:     geometry = load_geometry(geometry_file)
169:     _require(geometry.metadata["case_family"] == task["case_family"], "Task family differs from geometry", code="invalid_geometry")
170:     grid = geometry.grid
171:     _require(grid["shape_yx"] == [40, 80] and grid["origin_mm"] == [0.0, 0.0]
172:              and grid["cell_size_mm"] == [1.0, 1.0] and grid["extent_mm"] == [80.0, 40.0]
173:              and geometry.metadata["thickness_mm"] == 20.0
174:              and geometry.metadata["model_extent"]["kind"] == "lower_half",
175:              "HF-3 requires the unchanged native 80 by 40 mm, 1 mm grid, 20 mm thick lower half", code="invalid_geometry")
```

## HF — `hf_repo/src/hf_eval/project.py:210–249`

```text
210:         "medium_only_nodes": background_nodes[~attached[background_nodes]].tolist(),
211:         "dofs": groups["background_symmetry"].tolist(), "diagnostic_variant": variant,
212:     }
213:     fixed = np.unique(np.concatenate(list(groups.values())))
214:     solid_constraint_dofs = np.union1d(groups["support"], groups["entity_symmetry"])
215:     ports = {}
216:     vectors = {}
217:     for name, direction in (("input", [1.0, 0.0]), ("output", [-1.0, 0.0] if task["case_family"] == "inverter" else [0.0, 1.0])):
218:         _require(tags[name].get("direction") == direction, f"Unsupported {name} reference direction", code="invalid_geometry")
219:         vector, nodes, weights = port_vector(geometry, tags[name])
220:         _require(len(nodes) == 3 and np.array_equal(weights, [0.25, 0.5, 0.25]),
221:                  "Native project ports must retain all three original trapezoid weights", code="invalid_geometry")
222:         _require(np.all(attached[nodes]), f"Every original {name} port node must attach to solid", code="invalid_geometry")
223:         _require(not np.any(vector[fixed]), f"The {name} direction intersects a fixed displacement DOF", code="constraint_conflict")
224:         vectors[name] = _readonly(vector, float)
225:         ports[name] = {"tag": name, "points_mm": deepcopy(tags[name]["points_mm"]),
226:                        "direction": direction, "nodes": nodes.tolist(), "weights": weights.tolist(),
227:                        "averaging": tags[name]["averaging"], "nonzero_dofs": np.flatnonzero(vector).tolist()}
228:     solid = geometry.solid.ravel(order="C").astype(bool)
229:     factors = np.where(solid, 1.0, medium)
230:     lam = E * nu / ((1.0 + nu) * (1.0 - 2.0 * nu))
231:     mu = E / (2.0 * (1.0 + nu))
232:     kappa = E / (3.0 * (1.0 - 2.0 * nu))
233:     kr = alpha * length**2 * (kappa + 4.0 * mu / 3.0)
234:     model = TMCModel(coordinates, connectivity, lam * factors, mu * factors, kr,
235:                      1.0, 1.0, 20.0, solid, fixed)
236:     intersections = {}
237:     names = list(groups)
238:     for i, left in enumerate(names):
239:         for right in names[i+1:]:
240:             intersections[left+"__"+right] = np.intersect1d(groups[left], groups[right]).tolist()
241:     sources = {str(int(dof)): [name for name, dofs in groups.items() if dof in dofs] for dof in fixed}
242:     active = np.flatnonzero(attached)
243:     region_metadata.update({
244:         "units": deepcopy(UNITS), "ports": ports, "intersections": intersections,
245:         "fixed_dof_sources": sources, "fixed_dofs": fixed.tolist(),
246:         "solid_constraint_dofs": solid_constraint_dofs.tolist(),
247:         "counts": {"cells": model.ne, "nodes": len(coordinates), "dofs": model.ndof,
248:                    "solid_cells": int(solid.sum()), "medium_cells": int((~solid).sum()),
249:                    "solid_incident_nodes": len(active), "fixed_dofs": len(fixed)},
```

## HF — `hf_repo/src/hf_eval/evaluation.py:54–89`

```text
54:     """Read and qualify one geometry; schema failures remain distinct from geometry failures."""
55:     try:
56:         geometry = load_geometry(path)
57:         return {"readability": {"status": "pass"},
58:                 "geometry_id": geometry.geometry_id,
59:                 "case_family": geometry.metadata["case_family"],
60:                 "qualification": qualify_geometry(geometry)}
61:     except (ValueError, OSError, KeyError, TypeError) as error:
62:         return {"readability": {"status": "fail", "reason": str(error)},
63:                 "qualification": {"status": "not_evaluated"}}
64: 
65: 
66: def evaluate(geometry_file, task_config, solver_config, output_directory=None):
67:     """Return structured diagnostics, saving fresh result files when requested.
68: 
69:     Failure is represented by null target metrics and a stage/reason, never by
70:     a zero-valued performance result. A populated output directory is not reused.
71:     """
72:     # Dispatch before allocating output: the project wrapper owns atomic files.
73:     # Preserve the existing structured HF-1 error path for unreadable configs.
74:     try:
75:         declared_task = _config(task_config)
76:     except (ValueError, OSError, TypeError):
77:         declared_task = {}
78:     if declared_task.get("schema_version") == "hf-project-task-1.0":
79:         from .project_evaluation import evaluate_project
80:         return evaluate_project(geometry_file, declared_task, solver_config, output_directory)
81:     start = time.perf_counter()
82:     output = None
83:     if output_directory is not None:
84:         output = Path(output_directory)
85:         if output.exists() and any(output.iterdir()):
86:             raise FileExistsError(f"Refusing to overwrite evaluation directory: {output}")
87:         output.mkdir(parents=True, exist_ok=True)
88:     result = {
89:         "schema_version": "hf-result-1.0",
```

## HF — `hf_repo/src/hf_eval/project_evaluation.py:20–38`

```text
20: 
21: import numpy as np
22: 
23: from . import __version__
24: from .data import canonical_hash, load_geometry
25: from .displacement import DisplacementSettings, solve_displacement_path
26: from .evaluation import implementation_hash
27: from .project import UNITS, build_project
28: from .regions import qualify_geometry
29: from .tmc_kernel import KERNEL_VERSION
30: 
31: 
32: SOLVER_SCHEMA = "hf-project-solver-1.0"
33: STATE_ARRAYS = ("u", "J", "input_force", "spring_force_on_structure", "force_residual",
34:                 "support_reaction", "internal_force", "material_internal_force",
35:                 "regularization_internal_force", "material_energy", "global_force_balance")
36: 
37: 
38: def _jsonable(value):
```

## HF — `hf_repo/src/hf_eval/tmc_kernel.py:97–175`

```text
97: 
98: 
99: def _determinants(ue, grad):
100:     with np.errstate(over="ignore", invalid="ignore"):
101:         F = np.eye(2) + np.einsum("eai,qaj->eqij", ue.reshape(-1, 4, 2), grad)
102:         J = F[:, :, 0, 0]*F[:, :, 1, 1] - F[:, :, 0, 1]*F[:, :, 1, 0]
103:     if not np.all(np.isfinite(F)) or not np.all(np.isfinite(J)):
104:         raise KernelError("Deformation gradient or determinant is nonfinite.", code="nonfinite")
105:     return J
106: 
107: 
108: def determinants(ue, ops):
109:     """Evaluate J without any logarithm or inverse; nonpositive J is returned.
110: 
111:     Response calls use this inexpensive NumPy check before entering JAX. A
112:     nonlinear outer solver may also use it to reject a proposed trial early.
113:     """
114:     values = _array(ue, "displacement")
115:     single = values.shape == (8,)
116:     values = _displacements(values, single=single)
117:     reference = _ops(ops)
118:     J = _determinants(values.reshape(-1, 8), reference["grad"])
119:     return J[0] if single else J
120: 
121: 
122: def _runtime():
123:     if not jax.config.x64_enabled:
124:         raise KernelError("JAX float64 must be explicitly enabled before kernel use.", code="runtime_configuration")
125:     if jax.default_backend() != "cpu":
126:         raise KernelError("The HF-2 kernel requires the CPU backend.", code="runtime_configuration")
127: 
128: 
129: def _coefficient(value, name, count):
130:     result = _array(value, name)
131:     if result.shape == ():
132:         return np.full(count, float(result), dtype=np.float64)
133:     if result.shape != (count,):
134:         raise KernelError(f"{name} must be scalar or have shape ({count},).", code="invalid_shape")
135:     return result
136: 
137: 
138: def _residual_with_aux(u, grad, hessian, weights, lam, mu, kr):
139:     """Pure differentiable weak residual; validated inputs only."""
140:     nodal_u = u.reshape(4, 2)
141:     G = jnp.einsum("ai,qaj->qij", nodal_u, grad)
142:     F = jnp.eye(2, dtype=u.dtype) + G
143:     direct_J = F[:, 0, 0]*F[:, 1, 1] - F[:, 0, 1]*F[:, 1, 0]
144:     near_identity = jnp.max(jnp.abs(G), axis=(-1, -2)) <= 0.01
145:     delta = G[:, 0, 0]+G[:, 1, 1]+G[:, 0, 0]*G[:, 1, 1]-G[:, 0, 1]*G[:, 1, 0]
146:     safe_delta = jnp.where(near_identity, delta, 0.0)
147:     J = jnp.where(near_identity, 1.0+safe_delta, direct_J)
148:     inverse_transpose = jnp.stack((
149:         jnp.stack((F[:, 1, 1], -F[:, 1, 0]), axis=-1),
150:         jnp.stack((-F[:, 0, 1], F[:, 0, 0]), axis=-1),
151:     ), axis=-2) / J[:, None, None]
152:     log_J = jnp.where(near_identity, jnp.log1p(safe_delta), jnp.log(J))
153:     coefficient = lam*log_J-mu
154:     # Equivalent source weak form, without the ill-conditioned det(F.T @ F).
155:     direct_P = mu*F + coefficient[:, None, None]*inverse_transpose
156:     # (F F.T-I) F^-T = F-F^-T, formed from the displacement gradient.
157:     G_near = jnp.where(near_identity[:, None, None], G, 0.0)
158:     T_near = jnp.where(near_identity[:, None, None], inverse_transpose, jnp.eye(2, dtype=u.dtype))
159:     log_near = jnp.log1p(safe_delta)
160:     B = G_near+jnp.swapaxes(G_near, -1, -2)+jnp.einsum("qik,qjk->qij", G_near, G_near)
161:     incremental_P = mu*jnp.einsum("qik,qkj->qij", B, T_near) + lam*log_near[:, None, None]*T_near
162:     P = jnp.where(near_identity[:, None, None], incremental_P, direct_P)
163:     # Second Piola stress is auxiliary; it does not feed the material force.
164:     inverse_C = jnp.einsum("qki,qkj->qij", inverse_transpose, inverse_transpose)
165:     direct_S = mu*jnp.eye(2, dtype=u.dtype) + coefficient[:, None, None]*inverse_C
166:     S = jnp.where(near_identity[:, None, None], jnp.einsum("qki,qkj->qij", T_near, incremental_P), direct_S)
167:     material = jnp.einsum("q,qaj,qij->ai", weights, grad, P).reshape(8)
168:     Hu = jnp.einsum("ai,ajk->ijk", nodal_u, hessian)
169:     hessian_force = jnp.einsum("ajk,ijk->ai", hessian, Hu).reshape(8)
170:     regularization = kr*jnp.sum(weights*jnp.exp(-5*J))*hessian_force
171:     residual = material + regularization
172:     trace_C = jnp.sum(F*F, axis=(-1, -2))
173:     direct_energy = 0.5*(lam*log_J**2 + mu*(trace_C-2-2*log_J))
174:     remainder = jnp.zeros_like(safe_delta)
175:     for power in range(14, 1, -1):
```

## HF — `hf_repo/src/hf_eval/split_kernel.py:32–74`

```text
32:         valid = values.shape == (8,)
33:     else:
34:         valid = values.ndim == 2 and values.shape[1] == 8 and values.shape[0] > 0
35:     if not valid:
36:         raise KernelError(f"{name} must have shape {'(8,)' if single else '(ne,8), ne>0'}", code="invalid_shape")
37:     return values
38: 
39: 
40: def _kinematics(lift, fluctuation, grad, hessian, xp):
41:     """The same explicit operation order for one element or a NumPy batch."""
42:     shape = lift.shape[:-1] + (4, 2)
43:     L, w = lift.reshape(shape), fluctuation.reshape(shape)
44:     GL = xp.einsum("...ai,qaj->...qij", L, grad)
45:     Gw = xp.einsum("...ai,qaj->...qij", w, grad)
46:     G = GL + Gw
47:     F_left = xp.eye(2, dtype=lift.dtype) + GL
48:     if xp is jnp:
49:         # Parentheses alone do not define an optimization boundary for XLA.
50:         # The primitive has identity JVP/batching rules; no stop_gradient.
51:         F_left = jax.lax.optimization_barrier(F_left)
52:     F = F_left + Gw
53:     HL = xp.einsum("...ai,ajk->...ijk", L, hessian)
54:     Hw = xp.einsum("...ai,ajk->...ijk", w, hessian)
55:     Hu = HL + Hw
56:     near = xp.max(xp.abs(G), axis=(-1, -2)) <= 0.01
57:     delta = G[..., 0, 0] + G[..., 1, 1] + G[..., 0, 0]*G[..., 1, 1] - G[..., 0, 1]*G[..., 1, 0]
58:     near_delta = xp.where(near, delta, 0.0)
59:     direct_J = F[..., 0, 0]*F[..., 1, 1] - F[..., 0, 1]*F[..., 1, 0]
60:     J = xp.where(near, 1.0 + near_delta, direct_J)
61:     return dict(G=G, F=F, Hu=Hu, J=J, near=near, near_delta=near_delta)
62: 
63: 
64: def _numpy_kinematics(lift, fluctuation, ops):
65:     with np.errstate(over="ignore", invalid="ignore"):
66:         values = _kinematics(lift, fluctuation, ops["grad"], ops["hessian"], np)
67:     if any(not np.all(np.isfinite(values[key])) for key in ("G", "F", "Hu", "J")):
68:         raise KernelError("total split kinematics are nonfinite", code="nonfinite")
69:     return values
70: 
71: 
72: def determinants_split(lift_e, fluctuation_e, ops):
73:     """Return raw total J without logs/inverses, including nonpositive values.
74: 
```

## HF — `hf_repo/src/hf_eval/tmc.py:167–184`

```text
167: def _check_support(model):
168:     rigid = np.zeros((model.ndof, 3))
169:     rigid[0::2, 0] = 1
170:     rigid[1::2, 1] = 1
171:     span = max(np.ptp(model.coordinates, axis=0).max(), 1.0)
172:     center = model.coordinates.mean(axis=0)
173:     rigid[0::2, 2] = -(model.coordinates[:, 1] - center[1]) / span
174:     rigid[1::2, 2] = (model.coordinates[:, 0] - center[0]) / span
175:     if np.linalg.matrix_rank(rigid[model.fixed_dofs]) < 3:
176:         raise TMCError("support does not eliminate three planar rigid modes", code="insufficient_support")
177: 
178: 
179: def solve_path(model: TMCModel, F0, targets, settings=None, on_accept: Callable | None = None):
180:     """Bounded safeguarded Newton path, always starting from undeformed U=0.
181: 
182:     Only states passing the selected production residual criterion enter
183:     accepted_steps. Independent precision verification is a separate check.
184:     Trial failure preserves the last accepted state; incomplete targets return null metrics.
```

## HF — `hf_repo/src/hf_eval/displacement.py:95–113`

```text
95:     rigid = np.zeros((model.ndof, 3))
96:     rigid[0::2, 0], rigid[1::2, 1] = 1, 1
97:     center = model.coordinates.mean(axis=0)
98:     span = max(float(np.ptp(model.coordinates, axis=0).max()), 1.0)
99:     rigid[0::2, 2] = -(model.coordinates[:, 1] - center[1]) / span
100:     rigid[1::2, 2] = (model.coordinates[:, 0] - center[0]) / span
101:     if len(model.fixed_dofs) < 3 or np.linalg.matrix_rank(rigid[model.fixed_dofs]) < 3:
102:         raise TMCError("support does not eliminate three planar rigid modes", code="insufficient_support")
103: 
104: 
105: def _kkt(K, model, b_in, b_out, k_out):
106:     output = sparse.csc_matrix(b_out[:, None])
107:     total = (K + k_out * (output @ output.T)).tocsc()
108:     total.sum_duplicates()
109:     free_matrix = total[model.free][:, model.free].tocsc()
110:     column = sparse.csc_matrix(b_in[model.free, None])
111:     augmented = sparse.bmat([[free_matrix, -column], [column.T, None]], format="csc")
112:     if not np.all(np.isfinite(augmented.data)):
113:         raise TMCError("KKT matrix is nonfinite", code="nonfinite")
```

## HF — `hf_repo/tests/test_tmc.py:76–85`

```text
76: def test_zero_load_is_explicit_equilibrium_and_missing_support_is_failure():
77:     model=small_model()
78:     zero=solve_path(model,np.zeros(model.ndof),[0,.01,1])
79:     assert zero['status']=='success'
80:     np.testing.assert_array_equal(zero['u'],0)
81:     unconstrained=rectangular_model(2,1,2,1)
82:     failed=solve_path(unconstrained,load_for(unconstrained),[1])
83:     assert failed['status']=='failed'
84:     assert failed['failure']['code']=='insufficient_support'
85:     assert failed['target_metrics'] is None
```
