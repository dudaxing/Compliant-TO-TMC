"""Independent current-upload data checks; two tiny real HF solves (no LF import)."""
from pathlib import Path
from collections import Counter
import json, hashlib, time
import numpy as np
from scipy.ndimage import label, generate_binary_structure
from hf_eval.evaluation import evaluate, inspect_geometry
from hf_eval.data import load_geometry
from hf_eval.project import build_project
from hf_eval.displacement import solve_initial_tangent
BASE=Path('/mnt/data/review_20260927'); L=BASE/'repos/Diversity-TO-Compliant-O-main'; H=BASE/'repos/Compliant-TO-TMC-main'; E=BASE/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic(); result={}
formal=L/'research/n4_formal_gripper_v1'; idx=json.loads((formal/'index.json').read_text()); vols=[];unique=set(); failed=[]; comp_counts=Counter(); masks=[]
for row in idx['rows']:
    folder=formal/'export_v2'/row['id']; desc=json.loads((folder/'design.json').read_text())
    with np.load(folder/'design.npz',allow_pickle=False) as z:
        a={k:z[k].astype(bool) for k in z.files}
    s,d=a['solid'],a['design_domain']; v=int((s&d).sum())/int(d.sum()); vols.append(v)
    _,ncomp=label(s,generate_binary_structure(2,1));comp_counts[str(ncomp)]+=1
    unique.add(hashlib.sha256(s.tobytes()).hexdigest())
    checks={
       'json_hash':sha(folder/'design.json')==row['design_json_sha256'],
       'npz_hash':sha(folder/'design.npz')==row['design_npz_sha256']==desc['arrays']['sha256'],
       'shape':s.shape==(80,160),
       'volume_matches_index':v==row['binary_volume_fraction'],
       'binary_volume_le_limit':100*int((s&d).sum())<=35*int(d.sum()),
       'passive_solid':bool(np.all(s[a['passive_solid']])),
       'passive_void':bool(not np.any(s[a['passive_void']])),
       'single_four_connected':ncomp==1,
       'record_qualified':bool(row['strict_qualified'] and desc['qualification']['strict_qualified']),
    }
    if not all(checks.values()):failed.append({'id':row['id'],'checks':checks})
result['LF_formal_data']={'n_rows':len(idx['rows']),'success_records':sum(r['status']=='ok' for r in idx['rows']),
  'unique_binary_masks':len(unique),'binary_volume_range':[min(vols),max(vols)],'four_component_counts':dict(comp_counts),
  'failed_checks':failed,'scope':'Read current saved packages; no optimization rerun, no external raw histories audited.'}
err=json.loads((formal/'score_erratum_c1.json').read_text());result['LF_score_erratum']={k:err[k] for k in ['n_designs','frozen_k_in_N_per_mm','executed_k_in_N_per_mm','max_identity_reconstruction_relative_error','ratio_restored_over_executed']}
result['HF_source_geometry_equal_current_LF']={}
for case,ident in [('inverter','inverter__sweep__kin_1e+01__kout_1e-01'),('gripper','gripper__sweep__kin_1e+01__kout_1e+00')]:
    geom=load_geometry(H/f'geometry_dataset/canonical/{case}/geometry.json')
    with np.load(L/f'research/geometry_extraction_v1/candidates/{ident}/geometry.npz',allow_pickle=False) as z:
        clean=z['clean'].astype(np.uint8)
    result['HF_source_geometry_equal_current_LF'][case]={'id':ident,'shape':list(clean.shape),'changed_cells':int(np.count_nonzero(clean!=geom.arrays['solid']))}
result['LF_v2_direct_HF_inspect']=inspect_geometry(formal/'export_v2'/idx['rows'][0]['id']/'design.json')
(E/'data_checks.json').write_text(json.dumps(result,indent=2,ensure_ascii=False));print('data checks',time.monotonic()-start,'s',flush=True)
result['real_HF_smoke']={}
for case in ['inverter','gripper']:
    old=json.loads((H/f'hf3_results/{case}_path_001/result.json').read_text())
    task=old['task_config'];task['task_id']=f'review_{case}_tiny_free'; task['input']['target_mm']=1e-3
    solver=old['solver_config'];solver['solver_id']=f'review_{case}_tiny_free';solver['targets_mm']=[1e-3]
    solver['settings']['time_limit_seconds']=60.
    geom=H/f'geometry_dataset/canonical/{case}/geometry.json'
    project=build_project(geom,task)
    k0=solve_initial_tangent(project.model,project.bin,project.bout,project.k_out)
    run=evaluate(geom,task,solver,output_directory=E/f'{case}_tiny_free')
    metrics=run.get('target_metrics')
    result['real_HF_smoke'][case]={'numerics':run['numerics'],'qualification':run['qualification'],
      'target':None if metrics is None else {k:metrics[k] for k in ['d','q_in','q_out','R_input','relative_residual','minimum_J','relative_global_force_balance']},
      'qout_initial_tangent_mm':k0['q_out']*1e-3,'R_initial_tangent_N':k0['R_input']*1e-3,
      'scope':'One real 3200-element forward solve from undeformed state to d=0.001 mm, no workpiece, not HP independently audited.'}
    print(case,result['real_HF_smoke'][case],flush=True)
(E/'data_and_smoke_checks.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print('done',time.monotonic()-start,flush=True)
